// ===================================================================
// ApnaVault — frontend config for Netlify (static hosting)
// ===================================================================
// Is file me apne backend ka URL daalo. Backend ko Render / Railway /
// Fly.io par host karo (permanent disk ke saath), phir yahan uska URL.
//
// Example:
//   window.API_BASE = "https://apnavault-backend.onrender.com";
//
// Agar backend same domain par hai (proxy ke through), to khaali chhodo.
window.API_BASE = "";

// Login page ka path is site par. Netlify par "/" index.html deta hai.
window.LOGIN_PATH = "/";
