# ApnaVault — backend (photos/videos yahan permanently rehte hain)

Ye ek chhota Python (FastAPI) server hai. Isme:
- login / account banta hai
- photo, video, koi bhi file upload hoti hai
- thumbnail, favourite, trash, aur "Sab Recovery" (poori ZIP) milti hai
- sab data `VAULT_DATA_DIR` folder me safe rehta hai (phone reset se koi lena-dena nahi)

---

## Sabse aasan deploy: Render (2 click)

1. **render.com** par login karo (GitHub se login kar sakte ho).
2. **New +** → **Blueprint** chuno.
3. Apna GitHub repo chuno (jisme ye saari files hain).
   Render khud `render.yaml` padh lega — service, disk aur settings apne aap ban jayenge.
4. Bas **Apply / Deploy** dabao. 2-3 minute me URL mil jayega, jaise:
   `https://apnavault-backend.onrender.com`
5. Wo URL phone me kholo. Login + upload **wahi** hai. Ho gaya! ✅

> Note: permanent disk (jisme aapki photos rehti hain) ke liye Render ka
> Starter plan (~$7/month) chahiye. Free plan par disk nahi milti.

---

## Ya Docker se kahin bhi (Railway / Fly.io / apna PC)

```
docker build -t apnavault .
docker run -p 8000:8000 -v /some/permanent/folder:/data apnavault
```
Phir browser me: http://localhost:8000

Volume ko `/data` par mount karna **zaroori** hai, warna data ud jayega.

---

## Settings (env vars)

| Naam | Value | Kaam |
|---|---|---|
| `VAULT_DATA_DIR` | `/data` | files + database kahan rahen |
| `ALLOWED_ORIGINS` | `https://aapki-site.netlify.app` | Netlify wali site ko allow karne ke liye |
| `COOKIE_SECURE` | `1` | HTTPS par cookie safe rakhne ke liye |

Agar sirf backend use kar rahe ho (Netlify nahi), to `ALLOWED_ORIGINS` ki zaroorat nahi.

---

## Bina deploy, turant try karo (local)

```
pip install -r requirements.txt
VAULT_DATA_DIR=./data python -m uvicorn app.main:app --port 12000
```
Browser: http://localhost:12000
