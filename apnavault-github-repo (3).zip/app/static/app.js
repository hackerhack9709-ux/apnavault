'use strict';

// API_BASE is empty when the app is served by its own backend (local/Docker).
// On Netlify, set window.API_BASE in /static/config.js to the backend URL.
const API_BASE = (window.API_BASE || '').replace(/\/$/, '');
const LOGIN_PATH = window.LOGIN_PATH || '/login';
const api = (p) => API_BASE + p;
const apiFetch = (p, opts = {}) =>
  fetch(api(p), { credentials: 'include', ...opts });

const state = {
  view: 'all',
  kind: 'all',
  q: '',
  files: [],
  selected: new Set(),
};

const $ = (id) => document.getElementById(id);
const grid = $('grid');
const empty = $('empty');
const bulk = $('bulk');

function toast(text) {
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = text;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

function fmtTime(ts) {
  return ts ? ts.replace('T', ' ').slice(0, 16) : '';
}

// -------------------- Data loading --------------------
async function loadFiles() {
  const params = new URLSearchParams({ view: state.view, kind: state.kind, q: state.q });
  const res = await apiFetch('/api/files?' + params.toString());
  if (res.status === 401) { window.location.href = LOGIN_PATH; return; }
  const data = await res.json();
  state.files = data.files;
  state.selected.clear();
  $('stat-count').textContent = data.stats.count;
  $('stat-size').textContent = data.stats.size_h;
  render();
}

function isTrash() { return state.view === 'trash'; }

function render() {
  grid.innerHTML = '';
  const emptyText = isTrash()
    ? 'Trash khaali hai.'
    : state.q
      ? 'Is naam se kuch nahi mila.'
      : 'Abhi kuch nahi hai. Upar se upload karo.';
  $('empty-text').textContent = emptyText;
  empty.classList.toggle('hidden', state.files.length > 0);
  updateBulkBar();

  for (const f of state.files) {
    const card = document.createElement('div');
    card.className = 'card';
    card.dataset.id = f.id;

    let media;
    if (f.has_thumb) {
      media = `<img class="thumb" loading="lazy" src="${api('/api/thumb/' + f.id)}" alt="${esc(f.orig_name)}" />`;
    } else if (f.kind === 'video') {
      media = `<div class="thumb-ph">🎬</div>`;
    } else if (f.kind === 'image') {
      media = `<div class="thumb-ph">🖼️</div>`;
    } else {
      media = `<div class="thumb-ph">📄</div>`;
    }

    card.innerHTML = `
      ${media}
      <span class="badge">${f.kind}</span>
      ${f.starred && !isTrash() ? '<span class="star" style="pointer-events:none">★</span>' : ''}
      <label class="check-wrap">
        <input class="check" type="checkbox" data-id="${f.id}" />
      </label>
      <div class="card-meta">
        <div class="card-name" title="${esc(f.orig_name)}">${esc(f.orig_name)}</div>
        <div class="card-sub">${f.size_h} • ${fmtTime(f.uploaded_at)}</div>
      </div>`;

    card.addEventListener('click', (e) => {
      if (e.target.classList.contains('check')) return;
      openViewer(f);
    });
    grid.appendChild(card);
  }
}

function updateBulkBar() {
  const n = state.selected.size;
  bulk.classList.toggle('hidden', n === 0);
  $('sel-count').textContent = n + ' chuni gayi';
  const action = $('bulk-action');
  if (isTrash()) { action.textContent = '♻️ Restore karo'; }
  else if (state.view === 'starred') { action.textContent = '⭐ Star hatao'; }
  else { action.textContent = '🗑️ Trash me daalo'; }
}

grid.addEventListener('change', (e) => {
  if (!e.target.classList.contains('check')) return;
  const id = Number(e.target.dataset.id);
  if (e.target.checked) state.selected.add(id);
  else state.selected.delete(id);
  e.target.closest('.card').classList.toggle('selected', e.target.checked);
  updateBulkBar();
});

$('bulk-clear').onclick = () => {
  state.selected.clear();
  document.querySelectorAll('.check').forEach((c) => { c.checked = false; });
  document.querySelectorAll('.card').forEach((c) => c.classList.remove('selected'));
  updateBulkBar();
};

$('bulk-action').onclick = async () => {
  const ids = [...state.selected];
  if (!ids.length) return;
  let url, body;
  if (isTrash()) { url = '/api/restore'; body = { ids }; }
  else if (state.view === 'starred') {
    await Promise.all(ids.map((id) => apiFetch(`/api/file/${id}/star`, { method: 'POST' })));
    toast('Star hata diya'); loadFiles(); return;
  } else { url = '/api/trash'; body = { ids }; }
  await apiFetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  toast(isTrash() ? 'Wapas aa gaya ♻️' : 'Trash me daal diya');
  loadFiles();
};

// -------------------- Upload --------------------
const picker = $('picker');
const drop = $('drop');
const progress = $('progress');
const progressBar = $('progress-bar');
const progressTxt = $('progress-txt');

picker.addEventListener('change', () => {
  if (picker.files.length) uploadFiles([...picker.files]);
  picker.value = '';
});

['dragenter', 'dragover'].forEach((ev) =>
  drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('drag'); })
);
['dragleave', 'drop'].forEach((ev) =>
  drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('drag'); })
);
drop.addEventListener('drop', (e) => {
  if (e.dataTransfer.files.length) uploadFiles([...e.dataTransfer.files]);
});

function uploadFiles(files) {
  return new Promise((resolve) => {
    const fd = new FormData();
    files.forEach((f) => fd.append('files', f));
    const xhr = new XMLHttpRequest();
    xhr.open('POST', api('/api/upload'));
    xhr.withCredentials = true;
    progress.classList.remove('hidden');
    progressBar.style.width = '0%';
    progressTxt.textContent = '0%';

    xhr.upload.onprogress = (e) => {
      if (!e.lengthComputable) return;
      const pct = Math.round((e.loaded / e.total) * 100);
      progressBar.style.width = pct + '%';
      progressTxt.textContent = pct + '%  (' + files.length + ' file)';
    };
    xhr.onload = () => {
      progress.classList.add('hidden');
      if (xhr.status === 200) {
        const d = JSON.parse(xhr.responseText || '{}');
        toast((d.count || files.length) + ' file upload ho gayi ✅');
        loadFiles();
      } else if (xhr.status === 401) {
        window.location.href = LOGIN_PATH;
      } else {
        toast('Upload fail hua ❌');
      }
      resolve();
    };
    xhr.onerror = () => {
      progress.classList.add('hidden');
      toast('Network error — upload fail ❌');
      resolve();
    };
    xhr.send(fd);
  });
}

// -------------------- Viewer --------------------
const viewer = $('viewer');
const viewerBody = $('viewer-body');
const viewerBar = $('viewer-bar');

function openViewer(f) {
  viewerBody.innerHTML = '';
  viewerBar.innerHTML = '';
  const src = api(`/api/file/${f.id}/view`);

  if (f.kind === 'image') {
    const img = document.createElement('img');
    img.src = src;
    img.alt = f.orig_name;
    viewerBody.appendChild(img);
  } else if (f.kind === 'video') {
    const v = document.createElement('video');
    v.src = src;
    v.controls = true;
    v.autoplay = true;
    v.playsInline = true;
    viewerBody.appendChild(v);
  } else {
    const box = document.createElement('div');
    box.style.textAlign = 'center';
    box.innerHTML = `<div style="font-size:64px">📄</div><p>${esc(f.orig_name)}</p>
      <p class="muted small">Ye file browser me nahi khulti. Download karke kholo.</p>`;
    viewerBody.appendChild(box);
  }

  const name = document.createElement('span');
  name.className = 'name';
  name.textContent = f.orig_name;
  viewerBar.appendChild(name);

  const dl = document.createElement('a');
  dl.className = 'btn small';
  dl.href = api(`/api/file/${f.id}/download`);
  dl.textContent = '⬇️ Download';
  viewerBar.appendChild(dl);

  if (!isTrash()) {
    const star = document.createElement('button');
    star.className = 'btn small';
    star.textContent = f.starred ? '★ Star hatao' : '☆ Favourite';
    star.onclick = async () => {
      const r = await apiFetch(`/api/file/${f.id}/star`, { method: 'POST' });
      const d = await r.json();
      f.starred = d.starred ? 1 : 0;
      star.textContent = f.starred ? '★ Star hatao' : '☆ Favourite';
      loadFiles();
    };
    viewerBar.appendChild(star);

    const tr = document.createElement('button');
    tr.className = 'btn small danger';
    tr.textContent = '🗑️ Trash';
    tr.onclick = async () => {
      await apiFetch(`/api/file/${f.id}/trash`, { method: 'POST' });
      closeViewer();
      toast('Trash me daal diya');
      loadFiles();
    };
    viewerBar.appendChild(tr);
  } else {
    const rs = document.createElement('button');
    rs.className = 'btn small';
    rs.textContent = '♻️ Restore';
    rs.onclick = async () => {
      await apiFetch(`/api/file/${f.id}/restore`, { method: 'POST' });
      closeViewer();
      toast('Wapas aa gaya ♻️');
      loadFiles();
    };
    viewerBar.appendChild(rs);

    const del = document.createElement('button');
    del.className = 'btn small danger';
    del.textContent = '❌ Hamesha ke liye delete';
    del.onclick = async () => {
      if (!confirm('Pakka? Ye file hamesha ke liye delete ho jayegi.')) return;
      await apiFetch(`/api/file/${f.id}`, { method: 'DELETE' });
      closeViewer();
      toast('Delete ho gayi');
      loadFiles();
    };
    viewerBar.appendChild(del);
  }

  viewer.classList.remove('hidden');
}

function closeViewer() {
  viewer.classList.add('hidden');
  viewerBody.innerHTML = '';
}
$('viewer-close').onclick = closeViewer;
viewer.addEventListener('click', (e) => { if (e.target === viewer) closeViewer(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeViewer(); });

// -------------------- Controls --------------------
document.querySelectorAll('.view-btn').forEach((btn) => {
  btn.onclick = () => {
    document.querySelectorAll('.view-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    state.view = btn.dataset.view;
    $('empty-trash').classList.toggle('hidden', !isTrash());
    loadFiles();
  };
});

$('empty-trash').onclick = async () => {
  if (!confirm('Trash ki saari files hamesha ke liye delete ho jayengi. Pakka?')) return;
  const r = await apiFetch('/api/empty-trash', { method: 'POST' });
  const d = await r.json();
  toast((d.count || 0) + ' file delete ho gayi');
  loadFiles();
};

$('kind').onchange = (e) => { state.kind = e.target.value; loadFiles(); };
let searchTimer;
$('search').oninput = (e) => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { state.q = e.target.value.trim(); loadFiles(); }, 250);
};

$('logout-btn').onclick = async () => {
  await apiFetch('/api/logout', { method: 'POST' });
  window.location.href = LOGIN_PATH;
};

$('recover-btn').onclick = () => {
  toast('Recovery ZIP ban rahi hai... thodi der lagegi');
  window.location.href = api('/api/recover');
};

// -------------------- Boot --------------------
apiFetch('/api/me')
  .then((r) => (r.ok ? r.json() : Promise.reject()))
  .then((d) => { $('who').textContent = '@' + d.username; })
  .catch(() => { window.location.href = LOGIN_PATH; });

loadFiles();
