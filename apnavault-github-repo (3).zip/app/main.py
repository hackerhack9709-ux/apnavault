"""ApnaVault - personal cloud storage for photos, videos and files.

Runs as a small FastAPI service. Data lives on disk (./data) plus a SQLite
database, so it survives a phone factory reset: the phone is only a client.
"""
from __future__ import annotations

import hashlib
import io
import mimetypes
import os
import re
import secrets
import shutil
import sqlite3
import time
import zipfile
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator, Optional

import bcrypt
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import (
    FileResponse,
    HTMLResponse,
    JSONResponse,
    RedirectResponse,
    Response,
    StreamingResponse,
)
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from PIL import Image, ImageOps

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("VAULT_DATA_DIR", BASE_DIR / "data"))
FILES_DIR = DATA_DIR / "files"
THUMBS_DIR = DATA_DIR / "thumbs"
DB_PATH = DATA_DIR / "vault.db"
TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"
STATIC_DIR = Path(__file__).resolve().parent / "static"

SESSION_COOKIE = "vault_session"
SESSION_TTL = 60 * 60 * 24 * 30  # 30 days
CHUNK = 1024 * 1024
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tiff", ".heic"}
VIDEO_EXT = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v", ".3gp"}

for d in (FILES_DIR, THUMBS_DIR):
    d.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="ApnaVault")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

# Cross-origin: set ALLOWED_ORIGINS to your Netlify URL(s), comma-separated.
# Example: ALLOWED_ORIGINS="https://myvault.netlify.app"
_origins = [o.strip() for o in os.environ.get("ALLOWED_ORIGINS", "").split(",") if o.strip()]
if _origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

# When the frontend lives on another domain (Netlify), the session cookie must be
# SameSite=None; Secure. Set COOKIE_SECURE=1 in that case.
COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "0") == "1"


def set_session_cookie(resp: Response, token: str) -> None:
    resp.set_cookie(
        SESSION_COOKIE,
        token,
        max_age=SESSION_TTL,
        httponly=True,
        samesite="none" if COOKIE_SECURE else "lax",
        secure=COOKIE_SECURE,
        path="/",
    )


# --------------------------------------------------------------------------- #
# Database
# --------------------------------------------------------------------------- #
def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db() -> None:
    with closing(db()) as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                username      TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at    TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token      TEXT PRIMARY KEY,
                user_id    INTEGER NOT NULL,
                created_at REAL NOT NULL,
                expires_at REAL NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS files (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER NOT NULL,
                orig_name   TEXT NOT NULL,
                stored_name TEXT UNIQUE NOT NULL,
                size        INTEGER NOT NULL,
                mime        TEXT NOT NULL,
                kind        TEXT NOT NULL,
                thumb       TEXT,
                starred     INTEGER NOT NULL DEFAULT 0,
                deleted     INTEGER NOT NULL DEFAULT 0,
                uploaded_at TEXT NOT NULL,
                deleted_at  TEXT,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_files_user ON files(user_id, deleted);
            """
        )
        conn.commit()


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


# --------------------------------------------------------------------------- #
# Passwords & sessions
# --------------------------------------------------------------------------- #
def hash_password(password: str) -> str:
    digest = hashlib.sha256(password.encode("utf-8")).digest()
    return bcrypt.hashpw(digest, bcrypt.gensalt()).decode()


def verify_password(password: str, hashed: str) -> bool:
    digest = hashlib.sha256(password.encode("utf-8")).digest()
    try:
        return bcrypt.checkpw(digest, hashed.encode())
    except ValueError:
        return False


def create_session(conn: sqlite3.Connection, user_id: int) -> str:
    token = secrets.token_urlsafe(32)
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    now = time.time()
    conn.execute(
        "INSERT INTO sessions (token, user_id, created_at, expires_at) VALUES (?,?,?,?)",
        (token_hash, user_id, now, now + SESSION_TTL),
    )
    conn.execute("DELETE FROM sessions WHERE expires_at < ?", (now,))
    conn.commit()
    return token


def current_user(request: Request) -> Optional[sqlite3.Row]:
    token = request.cookies.get(SESSION_COOKIE)
    if not token:
        return None
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    with closing(db()) as conn:
        row = conn.execute(
            """
            SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id
            WHERE s.token = ? AND s.expires_at > ?
            """,
            (token_hash, time.time()),
        ).fetchone()
    return row


def require_user(request: Request) -> sqlite3.Row:
    user = current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="login required")
    return user


# --------------------------------------------------------------------------- #
# File helpers
# --------------------------------------------------------------------------- #
def classify(name: str, mime: str) -> str:
    ext = Path(name).suffix.lower()
    if ext in IMAGE_EXT or mime.startswith("image/"):
        return "image"
    if ext in VIDEO_EXT or mime.startswith("video/"):
        return "video"
    return "file"


def safe_name(name: str) -> str:
    name = os.path.basename(name or "file")
    name = re.sub(r"[^\w.\- ()\[\]]+", "_", name).strip() or "file"
    return name[:180]


def make_thumbnail(src: Path, dest: Path) -> bool:
    try:
        with Image.open(src) as im:
            im = ImageOps.exif_transpose(im)
            im = im.convert("RGB")
            im.thumbnail((480, 480))
            im.save(dest, "JPEG", quality=82)
        return True
    except Exception:
        return False


def human_size(num: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if num < 1024 or unit == "TB":
            return f"{num:.0f} {unit}" if unit == "B" else f"{num:.1f} {unit}"
        num /= 1024.0
    return f"{num:.1f} TB"


def file_row_to_dict(row: sqlite3.Row) -> dict:
    d = dict(row)
    d["size_h"] = human_size(d["size"])
    d["has_thumb"] = bool(d["thumb"])
    return d


def iter_file(path: Path, start: int, end: int) -> Iterator[bytes]:
    with open(path, "rb") as f:
        f.seek(start)
        remaining = end - start + 1
        while remaining > 0:
            chunk = f.read(min(CHUNK, remaining))
            if not chunk:
                break
            remaining -= len(chunk)
            yield chunk


def range_response(path: Path, request: Request, mime: str, download_name: Optional[str] = None):
    size = path.stat().st_size
    range_header = request.headers.get("range")
    disposition = "attachment" if download_name else "inline"
    fname = download_name or path.name
    headers = {
        "Accept-Ranges": "bytes",
        "Content-Disposition": f'{disposition}; filename="{fname}"',
    }
    if range_header:
        m = re.match(r"bytes=(\d*)-(\d*)", range_header)
        if m:
            start = int(m.group(1)) if m.group(1) else 0
            end = int(m.group(2)) if m.group(2) else size - 1
            end = min(end, size - 1)
            if start > end:
                raise HTTPException(status_code=416, detail="bad range")
            length = end - start + 1
            headers["Content-Range"] = f"bytes {start}-{end}/{size}"
            headers["Content-Length"] = str(length)
            return StreamingResponse(
                iter_file(path, start, end), status_code=206, headers=headers, media_type=mime
            )
    headers["Content-Length"] = str(size)
    return StreamingResponse(iter_file(path, 0, size - 1), headers=headers, media_type=mime)


# --------------------------------------------------------------------------- #
# Startup
# --------------------------------------------------------------------------- #
@app.on_event("startup")
def _startup() -> None:
    init_db()


# --------------------------------------------------------------------------- #
# Auth routes
# --------------------------------------------------------------------------- #
@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    user = current_user(request)
    if not user:
        return RedirectResponse("/login")
    return templates.TemplateResponse(request, "app.html", {"user": dict(user)})


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    if current_user(request):
        return RedirectResponse("/")
    with closing(db()) as conn:
        count = conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
    return templates.TemplateResponse(
        request, "login.html", {"needs_setup": count == 0}
    )


@app.post("/api/register")
def register(request: Request, username: str = Form(...), password: str = Form(...)):
    username = username.strip()
    if len(username) < 3:
        raise HTTPException(400, "Username kam se kam 3 letter ka hona chahiye.")
    if len(password) < 6:
        raise HTTPException(400, "Password kam se kam 6 character ka hona chahiye.")
    with closing(db()) as conn:
        exists = conn.execute("SELECT 1 FROM users WHERE username = ?", (username,)).fetchone()
        if exists:
            raise HTTPException(400, "Ye username pehle se liya hua hai.")
        cur = conn.execute(
            "INSERT INTO users (username, password_hash, created_at) VALUES (?,?,?)",
            (username, hash_password(password), now_iso()),
        )
        conn.commit()
        user_id = cur.lastrowid
        token = create_session(conn, user_id)
    resp = JSONResponse({"ok": True})
    set_session_cookie(resp, token)
    return resp


@app.post("/api/login")
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    with closing(db()) as conn:
        user = conn.execute(
            "SELECT * FROM users WHERE username = ?", (username.strip(),)
        ).fetchone()
        if not user or not verify_password(password, user["password_hash"]):
            raise HTTPException(401, "Galat username ya password.")
        token = create_session(conn, user["id"])
    resp = JSONResponse({"ok": True})
    set_session_cookie(resp, token)
    return resp


@app.post("/api/logout")
def logout(request: Request):
    token = request.cookies.get(SESSION_COOKIE)
    if token:
        with closing(db()) as conn:
            conn.execute(
                "DELETE FROM sessions WHERE token = ?",
                (hashlib.sha256(token.encode()).hexdigest(),),
            )
            conn.commit()
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(SESSION_COOKIE, path="/", samesite="none" if COOKIE_SECURE else "lax", secure=COOKIE_SECURE)
    return resp


@app.get("/api/me")
def me(request: Request):
    user = require_user(request)
    return {"username": user["username"]}


# --------------------------------------------------------------------------- #
# Upload / list / serve
# --------------------------------------------------------------------------- #
@app.post("/api/upload")
async def upload(request: Request, files: list[UploadFile] = File(...)):
    user = require_user(request)
    saved = []
    with closing(db()) as conn:
        for uf in files:
            orig = safe_name(uf.filename or "file")
            ext = Path(orig).suffix.lower()
            stored = f"{secrets.token_hex(16)}{ext}"
            dest = FILES_DIR / stored
            size = 0
            with open(dest, "wb") as out:
                while True:
                    chunk = await uf.read(CHUNK)
                    if not chunk:
                        break
                    size += len(chunk)
                    out.write(chunk)
            await uf.close()

            mime = uf.content_type or mimetypes.guess_type(orig)[0] or "application/octet-stream"
            kind = classify(orig, mime)
            thumb = None
            if kind == "image":
                thumb_file = f"{Path(stored).stem}.jpg"
                if make_thumbnail(dest, THUMBS_DIR / thumb_file):
                    thumb = thumb_file

            cur = conn.execute(
                """INSERT INTO files (user_id, orig_name, stored_name, size, mime, kind, thumb, uploaded_at)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (user["id"], orig, stored, size, mime, kind, thumb, now_iso()),
            )
            saved.append(cur.lastrowid)
        conn.commit()
        rows = conn.execute(
            f"SELECT * FROM files WHERE id IN ({','.join('?' * len(saved))})", saved
        ).fetchall() if saved else []
    return {"ok": True, "count": len(saved), "files": [file_row_to_dict(r) for r in rows]}


@app.get("/api/files")
def list_files(request: Request, view: str = "all", kind: str = "all", q: str = ""):
    user = require_user(request)
    where = ["user_id = ?"]
    params: list = [user["id"]]
    if view == "trash":
        where.append("deleted = 1")
    else:
        where.append("deleted = 0")
        if view == "starred":
            where.append("starred = 1")
        if kind in ("image", "video", "file"):
            where.append("kind = ?")
            params.append(kind)
        if q:
            where.append("orig_name LIKE ?")
            params.append(f"%{q}%")
    order = "uploaded_at DESC"
    sql = f"SELECT * FROM files WHERE {' AND '.join(where)} ORDER BY {order}"
    with closing(db()) as conn:
        rows = conn.execute(sql, params).fetchall()
        stats = conn.execute(
            """SELECT COUNT(*) c, COALESCE(SUM(size),0) s FROM files
               WHERE user_id = ? AND deleted = 0""",
            (user["id"],),
        ).fetchone()
    return {
        "files": [file_row_to_dict(r) for r in rows],
        "stats": {"count": stats["c"], "size": stats["s"], "size_h": human_size(stats["s"])},
    }


def _get_owned(conn: sqlite3.Connection, user_id: int, file_id: int) -> sqlite3.Row:
    row = conn.execute(
        "SELECT * FROM files WHERE id = ? AND user_id = ?", (file_id, user_id)
    ).fetchone()
    if not row:
        raise HTTPException(404, "File nahi mili.")
    return row


@app.get("/api/file/{file_id}/view")
def view_file(file_id: int, request: Request):
    user = require_user(request)
    with closing(db()) as conn:
        row = _get_owned(conn, user["id"], file_id)
    return range_response(FILES_DIR / row["stored_name"], request, row["mime"])


@app.get("/api/file/{file_id}/download")
def download_file(file_id: int, request: Request):
    user = require_user(request)
    with closing(db()) as conn:
        row = _get_owned(conn, user["id"], file_id)
    return range_response(
        FILES_DIR / row["stored_name"], request, row["mime"], download_name=row["orig_name"]
    )


@app.get("/api/thumb/{file_id}")
def thumb(file_id: int, request: Request):
    user = require_user(request)
    with closing(db()) as conn:
        row = _get_owned(conn, user["id"], file_id)
    if not row["thumb"]:
        raise HTTPException(404, "Thumbnail nahi hai.")
    path = THUMBS_DIR / row["thumb"]
    if not path.exists():
        raise HTTPException(404, "Thumbnail file gayab hai.")
    return FileResponse(path, media_type="image/jpeg")


# --------------------------------------------------------------------------- #
# Mutations: star / trash / restore / delete forever
# --------------------------------------------------------------------------- #
@app.post("/api/file/{file_id}/star")
def star_file(file_id: int, request: Request):
    user = require_user(request)
    with closing(db()) as conn:
        row = _get_owned(conn, user["id"], file_id)
        new = 0 if row["starred"] else 1
        conn.execute("UPDATE files SET starred = ? WHERE id = ?", (new, file_id))
        conn.commit()
    return {"ok": True, "starred": bool(new)}


def _soft_delete(conn: sqlite3.Connection, user_id: int, file_id: int) -> None:
    _get_owned(conn, user_id, file_id)
    conn.execute(
        "UPDATE files SET deleted = 1, deleted_at = ? WHERE id = ?", (now_iso(), file_id)
    )
    conn.commit()


@app.post("/api/file/{file_id}/trash")
def trash_file(file_id: int, request: Request):
    user = require_user(request)
    with closing(db()) as conn:
        _soft_delete(conn, user["id"], file_id)
    return {"ok": True}


@app.post("/api/trash")
def trash_many(request: Request, payload: dict):
    user = require_user(request)
    ids = payload.get("ids") or []
    with closing(db()) as conn:
        for fid in ids:
            _soft_delete(conn, user["id"], int(fid))
    return {"ok": True, "count": len(ids)}


@app.post("/api/file/{file_id}/restore")
def restore_file(file_id: int, request: Request):
    user = require_user(request)
    with closing(db()) as conn:
        _get_owned(conn, user["id"], file_id)
        conn.execute(
            "UPDATE files SET deleted = 0, deleted_at = NULL WHERE id = ?", (file_id,)
        )
        conn.commit()
    return {"ok": True}


@app.post("/api/restore")
def restore_many(request: Request, payload: dict):
    user = require_user(request)
    ids = payload.get("ids") or []
    with closing(db()) as conn:
        for fid in ids:
            _get_owned(conn, user["id"], int(fid))
            conn.execute(
                "UPDATE files SET deleted = 0, deleted_at = NULL WHERE id = ?", (int(fid),)
            )
        conn.commit()
    return {"ok": True, "count": len(ids)}


@app.delete("/api/file/{file_id}")
def delete_forever(file_id: int, request: Request):
    user = require_user(request)
    with closing(db()) as conn:
        row = _get_owned(conn, user["id"], file_id)
        conn.execute("DELETE FROM files WHERE id = ?", (file_id,))
        conn.commit()
    (FILES_DIR / row["stored_name"]).unlink(missing_ok=True)
    if row["thumb"]:
        (THUMBS_DIR / row["thumb"]).unlink(missing_ok=True)
    return {"ok": True}


@app.post("/api/empty-trash")
def empty_trash(request: Request):
    user = require_user(request)
    with closing(db()) as conn:
        rows = conn.execute(
            "SELECT * FROM files WHERE user_id = ? AND deleted = 1", (user["id"],)
        ).fetchall()
        conn.execute("DELETE FROM files WHERE user_id = ? AND deleted = 1", (user["id"],))
        conn.commit()
    for row in rows:
        (FILES_DIR / row["stored_name"]).unlink(missing_ok=True)
        if row["thumb"]:
            (THUMBS_DIR / row["thumb"]).unlink(missing_ok=True)
    return {"ok": True, "count": len(rows)}


# --------------------------------------------------------------------------- #
# Recovery: download everything as a ZIP (works even on a brand new phone)
# --------------------------------------------------------------------------- #
@app.get("/api/recover")
def recover_all(request: Request, kind: str = "all"):
    user = require_user(request)
    with closing(db()) as conn:
        if kind in ("image", "video", "file"):
            rows = conn.execute(
                "SELECT * FROM files WHERE user_id = ? AND deleted = 0 AND kind = ? ORDER BY uploaded_at",
                (user["id"], kind),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM files WHERE user_id = ? AND deleted = 0 ORDER BY uploaded_at",
                (user["id"],),
            ).fetchall()
    if not rows:
        raise HTTPException(404, "Recover karne ke liye koi file nahi hai.")

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        used: dict[str, int] = {}
        for row in rows:
            path = FILES_DIR / row["stored_name"]
            if not path.exists():
                continue
            arc = row["orig_name"]
            if arc in used:
                used[arc] += 1
                stem, ext = os.path.splitext(arc)
                arc = f"{stem}_{used[arc]}{ext}"
            else:
                used[arc] = 0
            zf.write(path, arcname=arc)
    buf.seek(0)
    stamp = datetime.now().strftime("%Y%m%d_%H%M")
    headers = {"Content-Disposition": f'attachment; filename="ApnaVault_recovery_{stamp}.zip"'}
    return StreamingResponse(iter(buf.read, b""), media_type="application/zip", headers=headers)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", "12000")))
