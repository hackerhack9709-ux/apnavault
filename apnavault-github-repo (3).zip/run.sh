#!/usr/bin/env bash
# ApnaVault chalane ke liye simple script.
set -e
cd "$(dirname "$0")"
PORT="${PORT:-12000}"
echo "ApnaVault start ho raha hai -> http://0.0.0.0:${PORT}"
exec python -m uvicorn app.main:app --host 0.0.0.0 --port "${PORT}"
