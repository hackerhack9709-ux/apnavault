"""ApnaVault-TG — personal cloud storage backed by Telegram.

Files (photos, videos, anything) are uploaded to your own Telegram account, so
storage is unlimited and free, and the data survives a phone factory reset:
the phone is only a client. A small JSON index keeps the file list; in Telegram
mode that index also lives in Telegram, so nothing is lost on server restart.

Run locally:
    STORAGE=local VAULT_DATA_DIR=./data uvicorn app_tg:app --port 12000

Run with Telegram:
    STORAGE=telegram TG_API_ID=.. TG_API_HASH=.. TG_SESSION=.. TG_CHAT_ID=.. \
        uvicorn app_tg:app --port 12000
"""
from __future__ import annotations

import asyncio
import hashlib
import io
import json
import mimetypes
import os
import re
import secrets
import tempfile
import threading
import time
import zipfile
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator, Optional

import bcrypt
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import (
    FileResponse,
    HTMLResponse,
    JSONResponse,
    RedirectResponse,
    Response,
    StreamingResponse,
)
from PIL import Image, ImageOps

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("VAULT_DATA_DIR", BASE_DIR / "data"))
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

SESSION_COOKIE = "vault_session"
SESSION_TTL = 60 * 60 * 24 * 30
CHUNK = 1024 * 1024
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tiff", ".heic"}
VIDEO_EXT = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v", ".3gp"}
COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "0") == "1"

app = FastAPI(title="ApnaVault-TG")

EMBEDDED = {'style.css': '/* ============================================================\n   APNAVAULT — "The Archive"\n   A vintage darkroom / analog photo-archive aesthetic.\n   Warm ink base, amber safelight, brass rules, aged paper cards,\n   typewriter metadata, editorial serif headlines, film grain.\n   ============================================================ */\n\n:root {\n  --ink:      #14100b;\n  --ink-2:    #1c1710;\n  --ink-3:    #241d13;\n  --paper:    #e8dfc9;\n  --paper-2:  #d9ccac;\n  --paper-3:  #f4ecd9;\n  --brass:    #c8a04a;\n  --brass-2:  #e6c778;\n  --stamp:    #a8392a;\n  --stamp-2:  #c14d3a;\n  --text:     #efe7d4;\n  --muted:    #9a8d74;\n  --line:     #3a3121;\n  --shadow:   0 22px 50px -20px rgba(0,0,0,.85);\n  --font-display: "Fraunces", Georgia, "Times New Roman", serif;\n  --font-body:    "Spectral", Georgia, serif;\n  --font-mono:    "Courier Prime", "Courier New", monospace;\n}\n\n* { box-sizing: border-box; }\nhtml { scroll-behavior: smooth; }\nbody {\n  margin: 0;\n  min-height: 100vh;\n  color: var(--text);\n  font-family: var(--font-body);\n  font-size: 16px;\n  background-color: var(--ink);\n  background-image:\n    radial-gradient(1100px 620px at 50% -8%, rgba(200,160,74,.20), transparent 62%),\n    radial-gradient(760px 520px at 88% 108%, rgba(168,57,42,.14), transparent 60%),\n    radial-gradient(600px 400px at 6% 96%, rgba(200,160,74,.08), transparent 60%);\n  position: relative;\n}\n\n/* film grain + vignette, layered over everything */\nbody::before {\n  content: "";\n  position: fixed; inset: 0; z-index: 1; pointer-events: none;\n  background: radial-gradient(120% 120% at 50% 45%, transparent 55%, rgba(0,0,0,.55) 100%);\n}\nbody::after {\n  content: "";\n  position: fixed; inset: -50%; z-index: 2; pointer-events: none;\n  opacity: .05; mix-blend-mode: overlay;\n  background-image: url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'180\' height=\'180\'%3E%3Cfilter id=\'n\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.85\' numOctaves=\'4\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23n)\'/%3E%3C/svg%3E");\n  animation: grain 900ms steps(3) infinite;\n}\n@keyframes grain {\n  0%   { transform: translate(0,0); }\n  33%  { transform: translate(-4%, 2%); }\n  66%  { transform: translate(3%, -3%); }\n  100% { transform: translate(0,0); }\n}\n\n.hidden { display: none !important; }\n.muted { color: var(--muted); }\n.small { font-size: .78rem; }\na { color: var(--brass-2); }\n\n/* ---------------- type helpers ---------------- */\n.eyebrow {\n  font-family: var(--font-mono);\n  font-size: .68rem;\n  letter-spacing: .34em;\n  text-transform: uppercase;\n  color: var(--brass);\n}\n.rule { height: 1px; background: linear-gradient(90deg, transparent, var(--line) 12%, var(--line) 88%, transparent); border: 0; margin: 0; }\n\n/* ---------------- buttons ---------------- */\n.btn {\n  font-family: var(--font-mono);\n  font-size: .74rem;\n  letter-spacing: .12em;\n  text-transform: uppercase;\n  color: var(--text);\n  background: linear-gradient(180deg, var(--ink-3), var(--ink-2));\n  border: 1px solid var(--line);\n  border-radius: 2px;\n  padding: 10px 15px;\n  cursor: pointer;\n  position: relative;\n  transition: transform .14s ease, border-color .14s ease, color .14s ease, box-shadow .14s ease;\n}\n.btn:hover { border-color: var(--brass); color: var(--brass-2); transform: translateY(-1px); box-shadow: 0 8px 18px -12px rgba(200,160,74,.9); }\n.btn:active { transform: translateY(0); }\n.btn.primary {\n  color: #1a130a;\n  background: linear-gradient(180deg, var(--brass-2), var(--brass));\n  border-color: var(--brass-2);\n  font-weight: 700;\n}\n.btn.primary:hover { color: #1a130a; filter: brightness(1.06); box-shadow: 0 10px 26px -12px rgba(230,199,120,.95); }\n.btn.ghost { background: transparent; }\n.btn.danger { color: #f0b6ac; border-color: #5c2b23; }\n.btn.danger:hover { color: #fff; border-color: var(--stamp-2); box-shadow: 0 8px 18px -12px rgba(193,77,58,.9); }\n.btn.small { padding: 7px 11px; font-size: .68rem; }\n.btn.full { width: 100%; padding: 14px; font-size: .82rem; }\n\n/* ============================================================\n   LOGIN\n   ============================================================ */\n.auth-body { display: grid; place-items: center; padding: 30px 20px; }\n.auth-card {\n  position: relative; z-index: 3;\n  width: 100%; max-width: 430px;\n  background:\n    linear-gradient(180deg, rgba(255,255,255,.35), transparent 30%),\n    linear-gradient(180deg, var(--paper-3), var(--paper));\n  color: #241d13;\n  border-radius: 3px;\n  padding: 30px 28px 26px;\n  box-shadow: var(--shadow), 0 0 0 1px rgba(0,0,0,.5);\n  animation: cardIn .7s cubic-bezier(.2,.8,.25,1) both;\n}\n/* torn top edge */\n.auth-card::before {\n  content: ""; position: absolute; left: 0; right: 0; top: -9px; height: 10px;\n  background: var(--paper-3);\n  clip-path: polygon(0 100%,2% 30%,5% 80%,8% 20%,12% 70%,16% 10%,21% 65%,26% 25%,31% 75%,36% 15%,42% 60%,48% 20%,54% 70%,60% 15%,66% 62%,72% 22%,78% 72%,84% 18%,90% 66%,95% 26%,100% 72%,100% 100%);\n}\n/* brass clip */\n.auth-card::after {\n  content: ""; position: absolute; top: -14px; left: 50%; transform: translateX(-50%);\n  width: 74px; height: 22px; border-radius: 3px;\n  background: linear-gradient(180deg, var(--brass-2), #8f6f2c);\n  box-shadow: 0 4px 10px -3px rgba(0,0,0,.6), inset 0 1px 0 rgba(255,255,255,.5);\n}\n@keyframes cardIn { from { opacity: 0; transform: translateY(18px) rotate(-.6deg); } to { opacity: 1; transform: none; } }\n\n.brand { text-align: center; margin-bottom: 6px; }\n.logo {\n  width: 66px; height: 66px; margin: 6px auto 12px;\n  display: grid; place-items: center; font-size: 30px;\n  border-radius: 50%;\n  background: radial-gradient(circle at 35% 30%, #2b2416, var(--ink));\n  border: 2px solid var(--brass);\n  box-shadow: 0 0 0 4px rgba(200,160,74,.16), inset 0 0 22px rgba(200,160,74,.28);\n}\n.brand h1 {\n  font-family: var(--font-display);\n  font-weight: 900; font-variation-settings: "opsz" 100, "SOFT" 40;\n  font-size: 2.15rem; letter-spacing: -.02em; margin: 2px 0 6px; color: #1c1509;\n}\n.brand p { margin: 0; color: #5c5140; font-size: .86rem; font-style: italic; }\n\n.banner {\n  margin-top: 16px; padding: 11px 13px;\n  font-family: var(--font-mono); font-size: .72rem; letter-spacing: .02em;\n  color: #6d2a1f;\n  background: rgba(168,57,42,.08);\n  border: 1px dashed rgba(168,57,42,.5);\n  border-radius: 2px;\n}\n\n.tabs { display: flex; gap: 0; margin: 20px 0 4px; border: 1px solid #b9ac8d; border-radius: 2px; overflow: hidden; }\n.tab {\n  flex: 1; cursor: pointer;\n  font-family: var(--font-mono); font-size: .72rem; letter-spacing: .14em; text-transform: uppercase;\n  padding: 11px; background: transparent; color: #6c5f49; border: 0;\n  transition: background .15s, color .15s;\n}\n.tab.active { background: #241d13; color: var(--brass-2); }\n\nlabel {\n  display: block; margin: 15px 0 6px;\n  font-family: var(--font-mono); font-size: .66rem; letter-spacing: .2em; text-transform: uppercase;\n  color: #6c5f49;\n}\ninput, select {\n  width: 100%; font-family: var(--font-mono); font-size: .92rem;\n  color: #241d13; background: transparent;\n  border: 0; border-bottom: 1.5px solid #9c8f72; border-radius: 0;\n  padding: 9px 2px;\n  transition: border-color .15s, background .15s;\n}\ninput::placeholder { color: #a99c80; }\ninput:focus, select:focus { outline: none; border-bottom-color: var(--stamp); background: rgba(200,160,74,.08); }\n#auth-form .btn { margin-top: 22px; }\n.msg { min-height: 20px; margin: 12px 0 0; font-family: var(--font-mono); font-size: .76rem; }\n.msg.error { color: #8f2f21; }\n.msg.ok { color: #3f6b2f; }\n.auth-card .muted.small { color: #7a6d55; }\n\n/* ============================================================\n   APP SHELL\n   ============================================================ */\n.topbar {\n  position: sticky; top: 0; z-index: 20;\n  display: flex; align-items: center; justify-content: space-between; gap: 14px;\n  padding: 12px 22px; flex-wrap: wrap;\n  background: rgba(18,14,9,.92);\n  backdrop-filter: blur(10px);\n  border-bottom: 1px solid var(--line);\n  box-shadow: 0 1px 0 rgba(200,160,74,.22);\n}\n.brand-row { display: flex; align-items: center; gap: 12px; }\n.logo.small {\n  width: 42px; height: 42px; font-size: 19px; border-radius: 50%; margin: 0;\n  display: grid; place-items: center;\n  background: radial-gradient(circle at 35% 30%, #2b2416, var(--ink));\n  border: 1.5px solid var(--brass);\n  box-shadow: inset 0 0 14px rgba(200,160,74,.3);\n}\n.brand-row strong {\n  display: block; font-family: var(--font-display); font-weight: 900;\n  font-size: 1.12rem; letter-spacing: .01em; color: var(--paper);\n}\n#who { font-family: var(--font-mono); font-size: .7rem; letter-spacing: .1em; color: var(--brass); }\n.top-actions { display: flex; gap: 8px; }\n\n.wrap { position: relative; z-index: 3; max-width: 1200px; margin: 0 auto; padding: 26px 22px 90px; }\n\n/* ---------------- hero / intake ---------------- */\n.hero { display: grid; grid-template-columns: 1.05fr 1fr; gap: 26px; align-items: stretch; margin-bottom: 22px; }\n.hero-left { display: flex; flex-direction: column; justify-content: center; }\n.hero h1 {\n  font-family: var(--font-display); font-weight: 900; font-variation-settings: "opsz" 144, "SOFT" 30;\n  font-size: clamp(2rem, 4.4vw, 3.1rem); line-height: .98; letter-spacing: -.025em;\n  margin: 12px 0 12px; color: var(--paper);\n}\n.hero h1 em { font-style: italic; color: var(--brass-2); }\n.hero .lede { color: var(--muted); max-width: 46ch; line-height: 1.6; font-size: .95rem; margin: 0; }\n\n.stats { display: flex; gap: 0; margin-top: 22px; border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); }\n.stat { flex: 1; padding: 14px 18px 14px 0; }\n.stat + .stat { padding-left: 20px; border-left: 1px solid var(--line); }\n.stat span { display: block; font-family: var(--font-display); font-weight: 700; font-size: 1.7rem; color: var(--brass-2); }\n.stat label { margin: 2px 0 0; color: var(--muted); font-size: .6rem; }\n\n/* ---------------- drop zone ---------------- */\n.drop {\n  position: relative; display: grid; place-items: center; min-height: 240px; cursor: pointer;\n  text-align: center; padding: 26px;\n  border: 1px dashed #6a5c3d;\n  border-radius: 3px;\n  background:\n    linear-gradient(180deg, rgba(200,160,74,.05), transparent),\n    repeating-linear-gradient(45deg, rgba(255,255,255,.012) 0 12px, transparent 12px 24px);\n  transition: border-color .2s, background .2s, transform .2s;\n}\n.drop::before, .drop::after {\n  content: ""; position: absolute; width: 16px; height: 16px; border: 1.5px solid var(--brass);\n  opacity: .7; transition: opacity .2s;\n}\n.drop::before { top: 9px; left: 9px; border-right: 0; border-bottom: 0; }\n.drop::after  { bottom: 9px; right: 9px; border-left: 0; border-top: 0; }\n.drop:hover, .drop.drag {\n  border-color: var(--brass-2); transform: translateY(-2px);\n  background: linear-gradient(180deg, rgba(200,160,74,.14), rgba(200,160,74,.03)), repeating-linear-gradient(45deg, rgba(255,255,255,.02) 0 12px, transparent 12px 24px);\n}\n.drop:hover::before, .drop:hover::after { opacity: 1; }\n.drop-ico { font-size: 34px; margin-bottom: 10px; filter: saturate(.6); }\n.drop-inner strong { display: block; font-family: var(--font-display); font-size: 1.15rem; color: var(--paper); margin-bottom: 4px; }\n.drop-inner .small { color: var(--muted); }\n\n/* ---------------- progress ---------------- */\n.progress {\n  position: relative; height: 30px; margin: 14px 0; overflow: hidden;\n  background: var(--ink-2); border: 1px solid var(--line); border-radius: 2px;\n}\n#progress-bar { height: 100%; width: 0; background: linear-gradient(90deg, #8f6f2c, var(--brass-2)); transition: width .2s; }\n#progress-txt { position: absolute; inset: 0; display: grid; place-items: center; font-family: var(--font-mono); font-size: .72rem; letter-spacing: .1em; color: #1a130a; font-weight: 700; }\n\n/* ---------------- toolbar ---------------- */\n.toolbar { display: flex; justify-content: space-between; gap: 14px; flex-wrap: wrap; align-items: center; margin: 26px 0 14px; }\n.views { display: flex; gap: 0; border: 1px solid var(--line); border-radius: 2px; overflow: hidden; }\n.view-btn {\n  cursor: pointer; background: transparent; border: 0; color: var(--muted);\n  font-family: var(--font-mono); font-size: .7rem; letter-spacing: .12em; text-transform: uppercase;\n  padding: 10px 15px; transition: background .15s, color .15s;\n}\n.view-btn + .view-btn { border-left: 1px solid var(--line); }\n.view-btn:hover { color: var(--brass-2); }\n.view-btn.active { background: var(--brass); color: #1a130a; font-weight: 700; }\n.filters { display: flex; gap: 10px; align-items: center; }\n.filters select, .filters input {\n  width: auto; background: var(--ink-2); border: 1px solid var(--line); border-radius: 2px;\n  color: var(--text); font-family: var(--font-mono); font-size: .74rem; padding: 9px 12px;\n}\n.filters select { color: var(--text); }\n.filters input { width: 210px; }\n.filters input::placeholder { color: #6f6350; }\n.filters input:focus, .filters select:focus { outline: none; border-color: var(--brass); background: var(--ink-3); }\n\n.bulk {\n  display: flex; align-items: center; gap: 12px; flex-wrap: wrap;\n  padding: 11px 15px; margin-bottom: 14px;\n  background: rgba(200,160,74,.07); border: 1px solid var(--line); border-left: 3px solid var(--brass); border-radius: 2px;\n}\n#sel-count { font-family: var(--font-mono); font-size: .74rem; letter-spacing: .08em; color: var(--brass-2); }\n\n/* ---------------- file grid ---------------- */\n.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(196px, 1fr)); gap: 20px; }\n\n.card {\n  position: relative; cursor: pointer;\n  background: linear-gradient(180deg, var(--paper-3), var(--paper));\n  color: #241d13;\n  border-radius: 2px;\n  padding: 9px 9px 0;\n  box-shadow: 0 14px 26px -16px rgba(0,0,0,.9), 0 0 0 1px rgba(0,0,0,.35);\n  transition: transform .2s cubic-bezier(.2,.8,.25,1), box-shadow .2s;\n  animation: cardRise .5s cubic-bezier(.2,.8,.25,1) both;\n}\n@keyframes cardRise { from { opacity: 0; transform: translateY(14px) rotate(0deg); } }\n.card:nth-child(4n+1) { transform: rotate(-.7deg); }\n.card:nth-child(4n+2) { transform: rotate(.5deg); }\n.card:nth-child(4n+3) { transform: rotate(-.3deg); }\n.card:nth-child(4n+4) { transform: rotate(.8deg); }\n.card:hover { transform: translateY(-6px) rotate(0deg) scale(1.015); box-shadow: 0 26px 44px -18px rgba(0,0,0,.95), 0 0 0 1px rgba(200,160,74,.5); z-index: 5; }\n.card.selected { box-shadow: 0 0 0 2px var(--brass), 0 20px 34px -18px rgba(0,0,0,.9); transform: translateY(-4px) rotate(0); }\n\n.thumb, .thumb-ph {\n  width: 100%; aspect-ratio: 1/1; display: block; object-fit: cover;\n  border-radius: 1px;\n  background: #2b2416;\n  filter: saturate(.92) contrast(1.03);\n}\n.thumb-ph { display: grid; place-items: center; font-size: 44px; filter: sepia(.35); background: linear-gradient(180deg, #2b2416, #1a140b); }\n\n/* stamp badge */\n.badge {\n  position: absolute; top: 14px; left: 14px;\n  font-family: var(--font-mono); font-size: .58rem; letter-spacing: .18em; text-transform: uppercase;\n  color: var(--stamp); padding: 3px 7px;\n  border: 1.5px solid var(--stamp);\n  border-radius: 2px;\n  background: rgba(244,236,217,.55);\n  transform: rotate(-6deg);\n  opacity: .85;\n  mix-blend-mode: multiply;\n}\n.star {\n  position: absolute; top: 12px; right: 12px; z-index: 3;\n  width: 30px; height: 30px; cursor: pointer; font-size: 15px; line-height: 1;\n  color: #6b5a30; background: rgba(244,236,217,.7); border: 1px solid rgba(0,0,0,.25);\n  border-radius: 50%; transition: transform .15s, color .15s;\n}\n.star:hover { transform: scale(1.12) rotate(8deg); color: var(--stamp); }\n\n.check-wrap { position: absolute; bottom: 46px; right: 12px; z-index: 3; }\n.check { width: 20px; height: 20px; accent-color: var(--stamp); cursor: pointer; }\n\n.card-meta { padding: 9px 3px 11px; border-top: 1px solid rgba(0,0,0,.14); margin-top: 9px; }\n.card-name {\n  font-family: var(--font-mono); font-size: .74rem; font-weight: 700;\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: #241d13;\n}\n.card-sub { font-family: var(--font-mono); font-size: .62rem; letter-spacing: .04em; color: #7a6d55; margin-top: 3px; }\n\n/* ---------------- empty ---------------- */\n.empty { text-align: center; padding: 70px 20px; color: var(--muted); }\n.empty-ico { font-size: 46px; margin-bottom: 14px; filter: sepia(.4); }\n#empty-text { font-family: var(--font-mono); font-size: .8rem; letter-spacing: .06em; }\n\n/* ---------------- viewer ---------------- */\n.viewer { position: fixed; inset: 0; z-index: 60; display: flex; flex-direction: column; background: rgba(8,6,3,.96); backdrop-filter: blur(4px); }\n.viewer-close {\n  position: absolute; top: 16px; right: 18px; z-index: 2;\n  width: 42px; height: 42px; border-radius: 50%; cursor: pointer;\n  font-size: 17px; color: var(--paper);\n  background: rgba(200,160,74,.14); border: 1px solid var(--line);\n  transition: background .15s, transform .15s;\n}\n.viewer-close:hover { background: rgba(200,160,74,.28); transform: rotate(90deg); }\n.viewer-body { flex: 1; display: grid; place-items: center; padding: 58px 20px 20px; overflow: auto; }\n.viewer-body img, .viewer-body video {\n  max-width: 92vw; max-height: 72vh; border-radius: 2px; background: #000;\n  box-shadow: 0 30px 60px -24px rgba(0,0,0,1), 0 0 0 1px rgba(200,160,74,.35);\n  animation: cardIn .4s ease both;\n}\n.viewer-bar {\n  display: flex; align-items: center; justify-content: center; gap: 12px; flex-wrap: wrap;\n  padding: 14px; border-top: 1px solid var(--line); background: rgba(18,14,9,.92);\n}\n.viewer-bar .name {\n  font-family: var(--font-mono); font-size: .74rem; color: var(--muted);\n  max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;\n}\n\n/* ---------------- toast ---------------- */\n.toast {\n  position: fixed; left: 50%; bottom: 26px; transform: translateX(-50%); z-index: 100;\n  font-family: var(--font-mono); font-size: .76rem; letter-spacing: .04em;\n  color: #1a130a; background: linear-gradient(180deg, var(--brass-2), var(--brass));\n  border-radius: 2px; padding: 12px 20px;\n  box-shadow: var(--shadow);\n  animation: toastIn .3s cubic-bezier(.2,.8,.25,1) both;\n}\n@keyframes toastIn { from { opacity: 0; transform: translate(-50%, 12px); } }\n\n/* ---------------- responsive ---------------- */\n@media (max-width: 820px) {\n  .hero { grid-template-columns: 1fr; gap: 20px; }\n  .drop { min-height: 180px; }\n  .toolbar { flex-direction: column; align-items: stretch; }\n  .views { justify-content: space-between; }\n  .filters { flex-wrap: wrap; }\n  .filters input { width: 100%; }\n  .grid { grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 14px; }\n}\n@media (max-width: 480px) {\n  .wrap { padding: 20px 14px 80px; }\n  .topbar { padding: 10px 14px; }\n  .grid { grid-template-columns: repeat(2, 1fr); }\n  .brand h1 { font-size: 1.85rem; }\n}\n@media (prefers-reduced-motion: reduce) {\n  *, *::before, *::after { animation: none !important; transition: none !important; }\n}\n', 'app.js': '\'use strict\';\n\n// API_BASE is empty when the app is served by its own backend (local/Docker).\n// On Netlify, set window.API_BASE in /static/config.js to the backend URL.\nconst API_BASE = (window.API_BASE || \'\').replace(/\\/$/, \'\');\nconst LOGIN_PATH = window.LOGIN_PATH || \'/login\';\nconst api = (p) => API_BASE + p;\nconst apiFetch = (p, opts = {}) =>\n  fetch(api(p), { credentials: \'include\', ...opts });\n\nconst state = {\n  view: \'all\',\n  kind: \'all\',\n  q: \'\',\n  files: [],\n  selected: new Set(),\n};\n\nconst $ = (id) => document.getElementById(id);\nconst grid = $(\'grid\');\nconst empty = $(\'empty\');\nconst bulk = $(\'bulk\');\n\nfunction toast(text) {\n  const el = document.createElement(\'div\');\n  el.className = \'toast\';\n  el.textContent = text;\n  document.body.appendChild(el);\n  setTimeout(() => el.remove(), 3200);\n}\n\nfunction esc(s) {\n  return String(s).replace(/[&<>"\']/g, (c) => (\n    { \'&\': \'&amp;\', \'<\': \'&lt;\', \'>\': \'&gt;\', \'"\': \'&quot;\', "\'": \'&#39;\' }[c]\n  ));\n}\n\nfunction fmtTime(ts) {\n  return ts ? ts.replace(\'T\', \' \').slice(0, 16) : \'\';\n}\n\n// -------------------- Data loading --------------------\nasync function loadFiles() {\n  const params = new URLSearchParams({ view: state.view, kind: state.kind, q: state.q });\n  const res = await apiFetch(\'/api/files?\' + params.toString());\n  if (res.status === 401) { window.location.href = LOGIN_PATH; return; }\n  const data = await res.json();\n  state.files = data.files;\n  state.selected.clear();\n  $(\'stat-count\').textContent = data.stats.count;\n  $(\'stat-size\').textContent = data.stats.size_h;\n  render();\n}\n\nfunction isTrash() { return state.view === \'trash\'; }\n\nfunction render() {\n  grid.innerHTML = \'\';\n  const emptyText = isTrash()\n    ? \'Trash khaali hai.\'\n    : state.q\n      ? \'Is naam se kuch nahi mila.\'\n      : \'Abhi kuch nahi hai. Upar se upload karo.\';\n  $(\'empty-text\').textContent = emptyText;\n  empty.classList.toggle(\'hidden\', state.files.length > 0);\n  updateBulkBar();\n\n  for (const f of state.files) {\n    const card = document.createElement(\'div\');\n    card.className = \'card\';\n    card.dataset.id = f.id;\n\n    let media;\n    if (f.has_thumb) {\n      media = `<img class="thumb" loading="lazy" src="${api(\'/api/thumb/\' + f.id)}" alt="${esc(f.orig_name)}" />`;\n    } else if (f.kind === \'video\') {\n      media = `<div class="thumb-ph">🎬</div>`;\n    } else if (f.kind === \'image\') {\n      media = `<div class="thumb-ph">🖼️</div>`;\n    } else {\n      media = `<div class="thumb-ph">📄</div>`;\n    }\n\n    card.innerHTML = `\n      ${media}\n      <span class="badge">${f.kind}</span>\n      ${f.starred && !isTrash() ? \'<span class="star" style="pointer-events:none">★</span>\' : \'\'}\n      <label class="check-wrap">\n        <input class="check" type="checkbox" data-id="${f.id}" />\n      </label>\n      <div class="card-meta">\n        <div class="card-name" title="${esc(f.orig_name)}">${esc(f.orig_name)}</div>\n        <div class="card-sub">${f.size_h} • ${fmtTime(f.uploaded_at)}</div>\n      </div>`;\n\n    card.addEventListener(\'click\', (e) => {\n      if (e.target.classList.contains(\'check\')) return;\n      openViewer(f);\n    });\n    grid.appendChild(card);\n  }\n}\n\nfunction updateBulkBar() {\n  const n = state.selected.size;\n  bulk.classList.toggle(\'hidden\', n === 0);\n  $(\'sel-count\').textContent = n + \' chuni gayi\';\n  const action = $(\'bulk-action\');\n  if (isTrash()) { action.textContent = \'♻️ Restore karo\'; }\n  else if (state.view === \'starred\') { action.textContent = \'⭐ Star hatao\'; }\n  else { action.textContent = \'🗑️ Trash me daalo\'; }\n}\n\ngrid.addEventListener(\'change\', (e) => {\n  if (!e.target.classList.contains(\'check\')) return;\n  const id = Number(e.target.dataset.id);\n  if (e.target.checked) state.selected.add(id);\n  else state.selected.delete(id);\n  e.target.closest(\'.card\').classList.toggle(\'selected\', e.target.checked);\n  updateBulkBar();\n});\n\n$(\'bulk-clear\').onclick = () => {\n  state.selected.clear();\n  document.querySelectorAll(\'.check\').forEach((c) => { c.checked = false; });\n  document.querySelectorAll(\'.card\').forEach((c) => c.classList.remove(\'selected\'));\n  updateBulkBar();\n};\n\n$(\'bulk-action\').onclick = async () => {\n  const ids = [...state.selected];\n  if (!ids.length) return;\n  let url, body;\n  if (isTrash()) { url = \'/api/restore\'; body = { ids }; }\n  else if (state.view === \'starred\') {\n    await Promise.all(ids.map((id) => apiFetch(`/api/file/${id}/star`, { method: \'POST\' })));\n    toast(\'Star hata diya\'); loadFiles(); return;\n  } else { url = \'/api/trash\'; body = { ids }; }\n  await apiFetch(url, {\n    method: \'POST\',\n    headers: { \'Content-Type\': \'application/json\' },\n    body: JSON.stringify(body),\n  });\n  toast(isTrash() ? \'Wapas aa gaya ♻️\' : \'Trash me daal diya\');\n  loadFiles();\n};\n\n// -------------------- Upload --------------------\nconst picker = $(\'picker\');\nconst drop = $(\'drop\');\nconst progress = $(\'progress\');\nconst progressBar = $(\'progress-bar\');\nconst progressTxt = $(\'progress-txt\');\n\npicker.addEventListener(\'change\', () => {\n  if (picker.files.length) uploadFiles([...picker.files]);\n  picker.value = \'\';\n});\n\n[\'dragenter\', \'dragover\'].forEach((ev) =>\n  drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add(\'drag\'); })\n);\n[\'dragleave\', \'drop\'].forEach((ev) =>\n  drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove(\'drag\'); })\n);\ndrop.addEventListener(\'drop\', (e) => {\n  if (e.dataTransfer.files.length) uploadFiles([...e.dataTransfer.files]);\n});\n\nfunction uploadFiles(files) {\n  return new Promise((resolve) => {\n    const fd = new FormData();\n    files.forEach((f) => fd.append(\'files\', f));\n    const xhr = new XMLHttpRequest();\n    xhr.open(\'POST\', api(\'/api/upload\'));\n    xhr.withCredentials = true;\n    progress.classList.remove(\'hidden\');\n    progressBar.style.width = \'0%\';\n    progressTxt.textContent = \'0%\';\n\n    xhr.upload.onprogress = (e) => {\n      if (!e.lengthComputable) return;\n      const pct = Math.round((e.loaded / e.total) * 100);\n      progressBar.style.width = pct + \'%\';\n      progressTxt.textContent = pct + \'%  (\' + files.length + \' file)\';\n    };\n    xhr.onload = () => {\n      progress.classList.add(\'hidden\');\n      if (xhr.status === 200) {\n        const d = JSON.parse(xhr.responseText || \'{}\');\n        toast((d.count || files.length) + \' file upload ho gayi ✅\');\n        loadFiles();\n      } else if (xhr.status === 401) {\n        window.location.href = LOGIN_PATH;\n      } else {\n        toast(\'Upload fail hua ❌\');\n      }\n      resolve();\n    };\n    xhr.onerror = () => {\n      progress.classList.add(\'hidden\');\n      toast(\'Network error — upload fail ❌\');\n      resolve();\n    };\n    xhr.send(fd);\n  });\n}\n\n// -------------------- Viewer --------------------\nconst viewer = $(\'viewer\');\nconst viewerBody = $(\'viewer-body\');\nconst viewerBar = $(\'viewer-bar\');\n\nfunction openViewer(f) {\n  viewerBody.innerHTML = \'\';\n  viewerBar.innerHTML = \'\';\n  const src = api(`/api/file/${f.id}/view`);\n\n  if (f.kind === \'image\') {\n    const img = document.createElement(\'img\');\n    img.src = src;\n    img.alt = f.orig_name;\n    viewerBody.appendChild(img);\n  } else if (f.kind === \'video\') {\n    const v = document.createElement(\'video\');\n    v.src = src;\n    v.controls = true;\n    v.autoplay = true;\n    v.playsInline = true;\n    viewerBody.appendChild(v);\n  } else {\n    const box = document.createElement(\'div\');\n    box.style.textAlign = \'center\';\n    box.innerHTML = `<div style="font-size:64px">📄</div><p>${esc(f.orig_name)}</p>\n      <p class="muted small">Ye file browser me nahi khulti. Download karke kholo.</p>`;\n    viewerBody.appendChild(box);\n  }\n\n  const name = document.createElement(\'span\');\n  name.className = \'name\';\n  name.textContent = f.orig_name;\n  viewerBar.appendChild(name);\n\n  const dl = document.createElement(\'a\');\n  dl.className = \'btn small\';\n  dl.href = api(`/api/file/${f.id}/download`);\n  dl.textContent = \'⬇️ Download\';\n  viewerBar.appendChild(dl);\n\n  if (!isTrash()) {\n    const star = document.createElement(\'button\');\n    star.className = \'btn small\';\n    star.textContent = f.starred ? \'★ Star hatao\' : \'☆ Favourite\';\n    star.onclick = async () => {\n      const r = await apiFetch(`/api/file/${f.id}/star`, { method: \'POST\' });\n      const d = await r.json();\n      f.starred = d.starred ? 1 : 0;\n      star.textContent = f.starred ? \'★ Star hatao\' : \'☆ Favourite\';\n      loadFiles();\n    };\n    viewerBar.appendChild(star);\n\n    const tr = document.createElement(\'button\');\n    tr.className = \'btn small danger\';\n    tr.textContent = \'🗑️ Trash\';\n    tr.onclick = async () => {\n      await apiFetch(`/api/file/${f.id}/trash`, { method: \'POST\' });\n      closeViewer();\n      toast(\'Trash me daal diya\');\n      loadFiles();\n    };\n    viewerBar.appendChild(tr);\n  } else {\n    const rs = document.createElement(\'button\');\n    rs.className = \'btn small\';\n    rs.textContent = \'♻️ Restore\';\n    rs.onclick = async () => {\n      await apiFetch(`/api/file/${f.id}/restore`, { method: \'POST\' });\n      closeViewer();\n      toast(\'Wapas aa gaya ♻️\');\n      loadFiles();\n    };\n    viewerBar.appendChild(rs);\n\n    const del = document.createElement(\'button\');\n    del.className = \'btn small danger\';\n    del.textContent = \'❌ Hamesha ke liye delete\';\n    del.onclick = async () => {\n      if (!confirm(\'Pakka? Ye file hamesha ke liye delete ho jayegi.\')) return;\n      await apiFetch(`/api/file/${f.id}`, { method: \'DELETE\' });\n      closeViewer();\n      toast(\'Delete ho gayi\');\n      loadFiles();\n    };\n    viewerBar.appendChild(del);\n  }\n\n  viewer.classList.remove(\'hidden\');\n}\n\nfunction closeViewer() {\n  viewer.classList.add(\'hidden\');\n  viewerBody.innerHTML = \'\';\n}\n$(\'viewer-close\').onclick = closeViewer;\nviewer.addEventListener(\'click\', (e) => { if (e.target === viewer) closeViewer(); });\ndocument.addEventListener(\'keydown\', (e) => { if (e.key === \'Escape\') closeViewer(); });\n\n// -------------------- Controls --------------------\ndocument.querySelectorAll(\'.view-btn\').forEach((btn) => {\n  btn.onclick = () => {\n    document.querySelectorAll(\'.view-btn\').forEach((b) => b.classList.remove(\'active\'));\n    btn.classList.add(\'active\');\n    state.view = btn.dataset.view;\n    $(\'empty-trash\').classList.toggle(\'hidden\', !isTrash());\n    loadFiles();\n  };\n});\n\n$(\'empty-trash\').onclick = async () => {\n  if (!confirm(\'Trash ki saari files hamesha ke liye delete ho jayengi. Pakka?\')) return;\n  const r = await apiFetch(\'/api/empty-trash\', { method: \'POST\' });\n  const d = await r.json();\n  toast((d.count || 0) + \' file delete ho gayi\');\n  loadFiles();\n};\n\n$(\'kind\').onchange = (e) => { state.kind = e.target.value; loadFiles(); };\nlet searchTimer;\n$(\'search\').oninput = (e) => {\n  clearTimeout(searchTimer);\n  searchTimer = setTimeout(() => { state.q = e.target.value.trim(); loadFiles(); }, 250);\n};\n\n$(\'logout-btn\').onclick = async () => {\n  await apiFetch(\'/api/logout\', { method: \'POST\' });\n  window.location.href = LOGIN_PATH;\n};\n\n$(\'recover-btn\').onclick = () => {\n  toast(\'Recovery ZIP ban rahi hai... thodi der lagegi\');\n  window.location.href = api(\'/api/recover\');\n};\n\n// -------------------- Boot --------------------\napiFetch(\'/api/me\')\n  .then((r) => (r.ok ? r.json() : Promise.reject()))\n  .then((d) => { $(\'who\').textContent = \'@\' + d.username; })\n  .catch(() => { window.location.href = LOGIN_PATH; });\n\nloadFiles();\n', 'app.html': '<!DOCTYPE html>\n<html lang="hi">\n<head>\n<meta charset="utf-8" />\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />\n<title>ApnaVault — Aapka Archive</title>\n<link rel="preconnect" href="https://fonts.googleapis.com" />\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\n<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,700;0,9..144,900;1,9..144,400;1,9..144,900&family=Spectral:ital,wght@0,400;0,600;1,400&family=Courier+Prime:wght@400;700&display=swap" rel="stylesheet" />\n<link rel="stylesheet" href="/static/style.css" />\n</head>\n<body>\n<header class="topbar">\n  <div class="brand-row">\n    <div class="logo small">🔒</div>\n    <div>\n      <strong>ApnaVault</strong>\n      <span class="muted small" id="who">—</span>\n    </div>\n  </div>\n  <div class="top-actions">\n    <button id="recover-btn" class="btn">⬇️ Sab Recovery</button>\n    <button id="logout-btn" class="btn ghost">Logout</button>\n  </div>\n</header>\n\n<main class="wrap">\n  <section class="hero">\n    <div class="hero-left">\n      <span class="eyebrow">Zaati digital archive · No. 001</span>\n      <h1>Jo bhi anmol hai,<br /><em>yahan sambhal ke</em> rakho.</h1>\n      <p class="lede">Photos, videos aur zaroori files ek surakshit jagah. Phone reset ho jaye,\n        phone kho jaye — aapka data yahin mehfooz rehta hai. Naye device se login karo aur sab wapas paa lo.</p>\n      <div class="stats">\n        <div class="stat"><span id="stat-count">0</span><label>files rakhi hui</label></div>\n        <div class="stat"><span id="stat-size">0 B</span><label>kul storage</label></div>\n      </div>\n    </div>\n    <label id="drop" class="drop">\n      <input id="picker" type="file" multiple hidden />\n      <div class="drop-inner">\n        <div class="drop-ico">🗂️</div>\n        <strong>Yahan chhodo, ya tap karo</strong>\n        <span class="small">Photos, videos aur koi bhi file — ek saath bahut saari</span>\n      </div>\n    </label>\n  </section>\n\n  <div id="progress" class="progress hidden"><div id="progress-bar"></div><span id="progress-txt">0%</span></div>\n\n  <nav class="toolbar">\n    <div class="views">\n      <button class="view-btn active" data-view="all">Sab</button>\n      <button class="view-btn" data-view="starred">⭐ Favourites</button>\n      <button class="view-btn" data-view="trash">🗑️ Trash</button>\n    </div>\n    <div class="filters">\n      <select id="kind">\n        <option value="all">Sab type</option>\n        <option value="image">Photos</option>\n        <option value="video">Videos</option>\n        <option value="file">Files</option>\n      </select>\n      <input id="search" type="search" placeholder="Naam se dhoondo..." />\n      <button id="empty-trash" class="btn small danger hidden">Trash khaali karo</button>\n    </div>\n  </nav>\n\n  <div id="bulk" class="bulk hidden">\n    <span id="sel-count">0 chuni gayi</span>\n    <button id="bulk-action" class="btn small">Karo</button>\n    <button id="bulk-clear" class="btn small ghost">Hatao</button>\n  </div>\n\n  <div id="empty" class="empty hidden">\n    <div class="empty-ico">📭</div>\n    <p id="empty-text">Abhi kuch nahi hai. Upar se upload karo.</p>\n  </div>\n\n  <section id="grid" class="grid"></section>\n</main>\n\n<div id="viewer" class="viewer hidden">\n  <button id="viewer-close" class="viewer-close">✕</button>\n  <div id="viewer-body" class="viewer-body"></div>\n  <div id="viewer-bar" class="viewer-bar"></div>\n</div>\n\n<script src="/static/app.js"></script>\n</body>\n</html>\n', 'login.html': '<!DOCTYPE html>\n<html lang="hi">\n<head>\n<meta charset="utf-8" />\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />\n<title>ApnaVault — Login</title>\n<link rel="preconnect" href="https://fonts.googleapis.com" />\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\n<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,700;0,9..144,900;1,9..144,400;1,9..144,900&family=Spectral:ital,wght@0,400;0,600;1,400&family=Courier+Prime:wght@400;700&display=swap" rel="stylesheet" />\n<link rel="stylesheet" href="/static/style.css" />\n</head>\n<body class="auth-body">\n  <div class="auth-card">\n    <div class="brand">\n      <div class="logo">🔒</div>\n      <h1>ApnaVault</h1>\n      <p>Est. 2026 · aapka zaati archive</p>\n    </div>\n\n    <div id="setup-banner" class="banner {% if not needs_setup %}hidden{% endif %}">\n      Pehli baar? Apna naya account banao — username + password chuno.\n    </div>\n\n    <div class="tabs">\n      <button id="tab-login" class="tab active" type="button">Login</button>\n      <button id="tab-register" class="tab" type="button">Naya Account</button>\n    </div>\n\n    <form id="auth-form" autocomplete="on">\n      <label for="username">Username</label>\n      <input id="username" name="username" type="text" placeholder="jaise: rahul123" required />\n\n      <label for="password">Password</label>\n      <input id="password" name="password" type="password" placeholder="kam se kam 6 character" required />\n\n      <button id="submit-btn" class="btn primary full" type="submit">Login karo</button>\n    </form>\n\n    <p id="msg" class="msg"></p>\n    <p class="muted small">Tip: password yaad rakho — isi se aapka poora data khulta hai.</p>\n  </div>\n  <script>\n    const form = document.getElementById(\'auth-form\');\n    const msg = document.getElementById(\'msg\');\n    const submitBtn = document.getElementById(\'submit-btn\');\n    const tabLogin = document.getElementById(\'tab-login\');\n    const tabReg = document.getElementById(\'tab-register\');\n    let mode = \'login\';\n\n    function setMode(next) {\n      mode = next;\n      tabLogin.classList.toggle(\'active\', mode === \'login\');\n      tabReg.classList.toggle(\'active\', mode === \'register\');\n      submitBtn.textContent = mode === \'login\' ? \'Login karo\' : \'Account banao\';\n      msg.textContent = \'\';\n    }\n    tabLogin.onclick = () => setMode(\'login\');\n    tabReg.onclick = () => setMode(\'register\');\n\n    form.addEventListener(\'submit\', async (e) => {\n      e.preventDefault();\n      msg.className = \'msg\';\n      msg.textContent = \'Ruko...\';\n      const body = new FormData(form);\n      const url = mode === \'login\' ? \'/api/login\' : \'/api/register\';\n      try {\n        const res = await fetch(url, { method: \'POST\', body });\n        const data = await res.json().catch(() => ({}));\n        if (!res.ok) throw new Error(data.detail || \'Kuch galat hua.\');\n        window.location.href = \'/\';\n      } catch (err) {\n        msg.className = \'msg error\';\n        msg.textContent = err.message;\n      }\n    });\n  </script>\n</body>\n</html>\n', 'setup.html': '<!DOCTYPE html>\n<html lang="hi">\n<head>\n<meta charset="utf-8" />\n<meta name="viewport" content="width=device-width, initial-scale=1" />\n<title>ApnaVault — Telegram jodo</title>\n<style>\n  :root{--ink:#14100b;--paper:#e8dfc9;--brass:#c8a04a;--brass2:#e6c778;--text:#efe7d4;--green:#2f7d4f;--red:#a8452f}\n  *{box-sizing:border-box}\n  body{margin:0;min-height:100vh;font-family:Georgia,serif;color:var(--text);\n    background:radial-gradient(1000px 600px at 50% -10%,rgba(200,160,74,.22),transparent 60%),var(--ink);\n    padding:26px 16px}\n  .wrap{max-width:600px;margin:0 auto}\n  h1{font-size:1.8rem;margin:0 0 6px}\n  .sub{color:#b8ab8e;font-style:italic;margin:0 0 20px}\n  .card{background:linear-gradient(180deg,var(--paper),#d9ccac);color:#241d13;border-radius:4px;\n    padding:22px;box-shadow:0 18px 44px -24px rgba(0,0,0,.85)}\n  .step{display:none}\n  .step.on{display:block}\n  .num{display:inline-block;background:var(--brass);color:#1a130a;font-family:\'Courier New\',monospace;\n    font-weight:700;font-size:.7rem;letter-spacing:.1em;padding:3px 9px;border-radius:2px;margin-bottom:10px}\n  h2{margin:0 0 12px;font-size:1.12rem}\n  p{margin:0 0 12px;font-size:.88rem;color:#5c5140;line-height:1.65}\n  label{display:block;font-family:\'Courier New\',monospace;font-size:.72rem;letter-spacing:.05em;\n    text-transform:uppercase;color:#6c5f49;margin:12px 0 5px}\n  input{width:100%;padding:12px;border:1px solid #b3a685;border-radius:2px;background:#fffdf6;\n    font-family:\'Courier New\',monospace;font-size:.95rem;color:#241d13}\n  input:focus{outline:2px solid var(--brass);border-color:var(--brass)}\n  button{margin-top:16px;width:100%;font-family:\'Courier New\',monospace;font-size:.82rem;letter-spacing:.05em;\n    text-transform:uppercase;color:#fff;background:linear-gradient(180deg,#4fae76,var(--green));\n    border:1px solid #4fae76;border-radius:2px;padding:15px;font-weight:700;cursor:pointer}\n  button:hover{filter:brightness(1.07)}\n  button:disabled{opacity:.55;cursor:wait}\n  a.link{color:#8a5a12;font-size:.85rem}\n  .help{background:rgba(0,0,0,.06);border-left:3px solid var(--brass);padding:10px 12px;margin:0 0 14px;\n    font-size:.82rem;color:#4a4030;line-height:1.6;border-radius:0 3px 3px 0}\n  .help b{color:#241d13}\n  .err{background:rgba(168,69,47,.14);border-left:3px solid var(--red);color:#8f2f1c;\n    padding:10px 12px;margin:12px 0 0;font-size:.83rem;border-radius:0 3px 3px 0;display:none}\n  .ok{font-size:2.6rem;text-align:center;margin:10px 0}\n  code{background:rgba(0,0,0,.08);padding:2px 5px;border-radius:2px;font-family:\'Courier New\',monospace;font-size:.82rem}\n</style>\n</head>\n<body>\n<div class="wrap">\n  <h1>ApnaVault — Telegram jodo</h1>\n  <p class="sub">Bas ek baar. Iske baad photos hamesha safe — unlimited, free.</p>\n\n  <div class="card">\n    <!-- STEP 1 -->\n    <div class="step on" id="s1">\n      <span class="num">STEP 1 / 3</span>\n      <h2>Telegram ki keys laao</h2>\n      <div class="help">\n        <b>Ye 2 minute ka kaam hai.</b><br>\n        1. Kholo 👉 <a class="link" href="https://my.telegram.org" target="_blank" rel="noopener">my.telegram.org</a><br>\n        2. Apna phone number daal ke login karo (Telegram app me code aayega).<br>\n        3. <b>"API development tools"</b> par click karo.<br>\n        4. Form bharo (App title: <code>apnavault</code>, Short name: <code>vault</code>, baaki khaali chhod do).<br>\n        5. <b>api_id</b> (number) aur <b>api_hash</b> (lamba text) copy karo.\n      </div>\n      <label>api_id</label>\n      <input id="api_id" inputmode="numeric" placeholder="jaise 1234567" autocomplete="off" />\n      <label>api_hash</label>\n      <input id="api_hash" placeholder="jaise a1b2c3d4e5f6..." autocomplete="off" />\n      <label>Telegram phone number</label>\n      <input id="phone" inputmode="tel" placeholder="+919876543210" autocomplete="off" />\n      <button id="b1">Aage badho →</button>\n      <div class="err" id="e1"></div>\n    </div>\n\n    <!-- STEP 2 -->\n    <div class="step" id="s2">\n      <span class="num">STEP 2 / 3</span>\n      <h2>Telegram par aaya code daalo</h2>\n      <p>Telegram app me ek <b>5 digit ka code</b> aaya hoga. Wahi neeche daalo.</p>\n      <label>Code</label>\n      <input id="code" inputmode="numeric" placeholder="12345" autocomplete="off" />\n      <button id="b2">Verify karo →</button>\n      <div class="err" id="e2"></div>\n    </div>\n\n    <!-- STEP 2b: 2FA password -->\n    <div class="step" id="s2b">\n      <span class="num">STEP 2 / 3</span>\n      <h2>Telegram ka password daalo</h2>\n      <p>Tumne Telegram par <b>two-step verification</b> lagayi hai. Wo password daalo.</p>\n      <label>Telegram password</label>\n      <input id="pw" type="password" placeholder="apna telegram password" autocomplete="off" />\n      <button id="b2b">Aage badho →</button>\n      <div class="err" id="e2b"></div>\n    </div>\n\n    <!-- STEP 3 -->\n    <div class="step" id="s3">\n      <span class="num">STEP 3 / 3</span>\n      <h2>Ho gaya! 🎉</h2>\n      <div class="ok">✅</div>\n      <p>Tumhara Telegram jud gaya. Ab jo bhi photo/video daaloge — Telegram me hamesha safe rahega.</p>\n      <p style="font-size:.82rem">Telegram app kholo → <b>"Saved Messages"</b> — tumhari files wahan dikhengi.</p>\n      <button id="b3">ApnaVault kholo →</button>\n\n      <div id="keybox" style="display:none;margin-top:22px;border-top:1px dashed #b3a685;padding-top:16px">\n        <h2 style="font-size:.95rem">Server ke liye ek key (save kar lo)</h2>\n        <p style="font-size:.82rem">Ye key is app ko batati hai ki tumhara Telegram kaunsa hai. Host (Render) ki\n        settings me <code>TG_CONFIG</code> naam se paste karni hai — taaki restart par bhi juda rahe.</p>\n        <textarea id="ckey" readonly style="width:100%;height:70px;font-family:\'Courier New\',monospace;font-size:.72rem;\n          border:1px solid #b3a685;border-radius:2px;padding:8px;background:#fffdf6;color:#241d13"></textarea>\n        <button id="bcopy" style="margin-top:8px;background:linear-gradient(180deg,var(--brass2),var(--brass));color:#1a130a;border-color:var(--brass2)">📋 Key copy karo</button>\n      </div>\n    </div>\n  </div>\n</div>\n\n<script>\n\'use strict\';\nconst $ = (id) => document.getElementById(id);\nfunction show(id){ document.querySelectorAll(\'.step\').forEach(s=>s.classList.remove(\'on\')); $(id).classList.add(\'on\'); }\nfunction err(el,msg){ el.textContent = msg; el.style.display = msg ? \'block\' : \'none\'; }\n\nasync function post(url, form){\n  const r = await fetch(url, { method:\'POST\', body: form, credentials:\'include\' });\n  let d = {};\n  try { d = await r.json(); } catch(e){}\n  if(!r.ok) throw new Error(d.detail || \'Kuch galat ho gaya. Dobara try karo.\');\n  return d;\n}\n\n$(\'b1\').onclick = async () => {\n  const btn = $(\'b1\'); err($(\'e1\'),\'\');\n  const fd = new FormData();\n  fd.append(\'api_id\', $(\'api_id\').value.trim());\n  fd.append(\'api_hash\', $(\'api_hash\').value.trim());\n  fd.append(\'phone\', $(\'phone\').value.trim());\n  if(!fd.get(\'api_id\')||!fd.get(\'api_hash\')||!fd.get(\'phone\')){ err($(\'e1\'),\'Teeno cheezein bharo.\'); return; }\n  btn.disabled = true; btn.textContent = \'Code bhej rahe hain...\';\n  try {\n    await post(\'/api/setup/start\', fd);\n    show(\'s2\');\n  } catch(e){ err($(\'e1\'), e.message); }\n  btn.disabled = false; btn.textContent = \'Aage badho →\';\n};\n\n$(\'b2\').onclick = async () => {\n  const btn = $(\'b2\'); err($(\'e2\'),\'\');\n  const fd = new FormData(); fd.append(\'code\', $(\'code\').value.trim());\n  if(!fd.get(\'code\')){ err($(\'e2\'),\'Code daalo.\'); return; }\n  btn.disabled = true; btn.textContent = \'Check kar rahe hain...\';\n  try {\n    const d = await post(\'/api/setup/code\', fd);\n    if(d.step === \'password\') show(\'s2b\');\n    else showDone(d);\n  } catch(e){ err($(\'e2\'), e.message); }\n  btn.disabled = false; btn.textContent = \'Verify karo →\';\n};\n\n$(\'b2b\').onclick = async () => {\n  const btn = $(\'b2b\'); err($(\'e2b\'),\'\');\n  const fd = new FormData(); fd.append(\'password\', $(\'pw\').value);\n  if(!fd.get(\'password\')){ err($(\'e2b\'),\'Password daalo.\'); return; }\n  btn.disabled = true; btn.textContent = \'Check kar rahe hain...\';\n  try {\n    const d = await post(\'/api/setup/password\', fd);\n    showDone(d);\n  } catch(e){ err($(\'e2b\'), e.message); }\n  btn.disabled = false; btn.textContent = \'Aage badho →\';\n};\n\nfunction showDone(d){\n  if(d && d.config_key){\n    $(\'ckey\').value = d.config_key;\n    $(\'keybox\').style.display = \'block\';\n  }\n  show(\'s3\');\n}\n\n$(\'bcopy\').onclick = async () => {\n  const t = $(\'ckey\');\n  try { await navigator.clipboard.writeText(t.value); $(\'bcopy\').textContent = \'✅ Copy ho gaya\'; }\n  catch(e){ t.select(); document.execCommand(\'copy\'); $(\'bcopy\').textContent = \'✅ Copy ho gaya\'; }\n};\n\n$(\'b3\').onclick = () => { window.location.href = \'/login\'; };\n</script>\n</body>\n</html>\n'}


# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #
def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def human_size(num: int) -> str:
    f = float(num)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if f < 1024 or unit == "TB":
            return f"{f:.0f} {unit}" if unit == "B" else f"{f:.1f} {unit}"
        f /= 1024.0
    return f"{f:.1f} TB"


def classify(name: str, mime: str) -> str:
    ext = Path(name).suffix.lower()
    if ext in IMAGE_EXT or mime.startswith("image/"):
        return "image"
    if ext in VIDEO_EXT or mime.startswith("video/"):
        return "video"
    return "file"


def safe_name(name: str) -> str:
    name = os.path.basename(name or "file")
    name = re.sub(r"[^\w.\- ()\[\]]+", "_", name).strip() or "file"
    return name[:180]


def hash_password(password: str) -> str:
    digest = hashlib.sha256(password.encode("utf-8")).digest()
    return bcrypt.hashpw(digest, bcrypt.gensalt()).decode()


def verify_password(password: str, hashed: str) -> bool:
    digest = hashlib.sha256(password.encode("utf-8")).digest()
    try:
        return bcrypt.checkpw(digest, hashed.encode())
    except ValueError:
        return False


def thumb_bytes(data: bytes) -> Optional[bytes]:
    try:
        with Image.open(io.BytesIO(data)) as im:
            im = ImageOps.exif_transpose(im)
            im = im.convert("RGB")
            im.thumbnail((480, 480))
            out = io.BytesIO()
            im.save(out, "JPEG", quality=82)
        return out.getvalue()
    except Exception:
        return None


# --------------------------------------------------------------------------- #
# Storage backends (synchronous interface, safe to call from any thread)
# --------------------------------------------------------------------------- #
class LocalStorage:
    kind = "local"

    def __init__(self, root: Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def _p(self, key: str) -> Path:
        p = self.root / key
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    def connect(self) -> None:
        return None

    def put(self, key: str, data: bytes) -> None:
        self._p(key).write_bytes(data)

    def get(self, key: str) -> Optional[bytes]:
        p = self._p(key)
        return p.read_bytes() if p.exists() else None

    def delete(self, key: str) -> None:
        p = self._p(key)
        if p.exists():
            p.unlink()

    def stream(self, key: str, start: int = 0, length: Optional[int] = None) -> Iterator[bytes]:
        with self._p(key).open("rb") as f:
            f.seek(start)
            remaining = length
            while True:
                n = 64 * 1024 if remaining is None else min(64 * 1024, remaining)
                if n <= 0:
                    break
                chunk = f.read(n)
                if not chunk:
                    break
                if remaining is not None:
                    remaining -= len(chunk)
                yield chunk

    def size(self, key: str) -> int:
        p = self._p(key)
        return p.stat().st_size if p.exists() else 0

    def load_index(self) -> Optional[bytes]:
        return self.get("_index.json")

    def save_index(self, raw: bytes) -> None:
        self.put("_index.json", raw)


class TelegramStore:
    """Files live in a Telegram chat. A private event loop runs in a thread."""

    kind = "telegram"

    def __init__(self, api_id, api_hash, session: str, chat_id):
        self.chat_id = chat_id if str(chat_id).lower() in ("me", "self") else int(chat_id)
        self._api_id = int(api_id)
        self._api_hash = api_hash
        self._session = session
        self._msg_ids: dict[str, int] = {}
        self._loop = asyncio.new_event_loop()
        self._ready = threading.Event()
        self._error: Optional[BaseException] = None
        self._thread = threading.Thread(target=self._thread_main, daemon=True)
        self._thread.start()
        if not self._ready.wait(90):
            raise RuntimeError("Telegram connect timeout")
        if self._error:
            raise self._error

    # --- event-loop plumbing ---
    def _thread_main(self) -> None:
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._connect())
        except BaseException as exc:  # noqa: BLE001
            self._error = exc
            self._ready.set()
            return
        self._ready.set()
        self._loop.run_forever()

    async def _connect(self) -> None:
        from telethon import TelegramClient
        from telethon.sessions import StringSession

        self._client = TelegramClient(
            StringSession(self._session), self._api_id, self._api_hash
        )
        await self._client.connect()
        if not await self._client.is_user_authorized():
            raise RuntimeError("Telegram session invalid — /setup dobara karo.")
        async for msg in self._client.iter_messages(self.chat_id):
            key = self._key_of(msg)
            if key and key not in self._msg_ids:
                self._msg_ids[key] = msg.id

    def _call(self, coro):
        return asyncio.run_coroutine_threadsafe(coro, self._loop).result()

    @staticmethod
    def _key_of(msg) -> Optional[str]:
        text = getattr(msg, "message", None) or getattr(msg, "text", None)
        if not text:
            return None
        for line in text.splitlines():
            if line.startswith("key="):
                return line[4:].strip()
        return None

    # --- interface ---
    def connect(self) -> None:
        return None

    async def _put(self, key: str, data: bytes) -> None:
        buf = io.BytesIO(data)
        buf.name = key.split("/")[-1]
        msg = await self._client.send_file(
            self.chat_id, buf, caption=f"key={key}", force_document=True
        )
        old = self._msg_ids.get(key)
        if old and old != msg.id:
            try:
                await self._client.delete_messages(self.chat_id, [old])
            except Exception:
                pass
        self._msg_ids[key] = msg.id

    def put(self, key: str, data: bytes) -> None:
        self._call(self._put(key, data))

    async def _get(self, key: str) -> Optional[bytes]:
        mid = self._msg_ids.get(key)
        if not mid:
            return None
        return await self._client.download_media(mid, bytes)

    def get(self, key: str) -> Optional[bytes]:
        return self._call(self._get(key))

    async def _delete(self, key: str) -> None:
        mid = self._msg_ids.pop(key, None)
        if mid:
            try:
                await self._client.delete_messages(self.chat_id, [mid])
            except Exception:
                pass

    def delete(self, key: str) -> None:
        self._call(self._delete(key))

    async def _stream(self, key: str, start: int, length: Optional[int]):
        mid = self._msg_ids.get(key)
        if not mid:
            return
        async for chunk in self._client.iter_download(
            mid, offset=start, request_size=512 * 1024, chunk_size=512 * 1024
        ):
            if length is not None:
                if length <= 0:
                    break
                if len(chunk) > length:
                    chunk = chunk[:length]
            yield chunk
            if length is not None:
                length -= len(chunk)

    def stream(self, key: str, start: int = 0, length: Optional[int] = None) -> Iterator[bytes]:
        agen = self._stream(key, start, length).__aiter__()
        while True:
            try:
                yield self._call(agen.__anext__())
            except StopAsyncIteration:
                break

    async def _size(self, key: str) -> int:
        mid = self._msg_ids.get(key)
        if not mid:
            return 0
        msg = await self._client.get_messages(self.chat_id, ids=mid)
        doc = getattr(msg, "document", None)
        return int(doc.size) if doc else 0

    def size(self, key: str) -> int:
        return self._call(self._size(key))

    def load_index(self) -> Optional[bytes]:
        return self.get("_index.json")

    def save_index(self, raw: bytes) -> None:
        self.put("_index.json", raw)


CONFIG_PATH = DATA_DIR / "config.json"


def load_config() -> dict:
    """Telegram credentials: env vars win, else config.json on the data dir."""
    cfg = {}
    if CONFIG_PATH.exists():
        try:
            cfg = json.loads(CONFIG_PATH.read_text("utf-8"))
        except Exception:
            cfg = {}
    # A single base64 blob is the easiest thing to paste into a host's dashboard.
    if os.environ.get("TG_CONFIG"):
        try:
            cfg.update(config_from_key(os.environ["TG_CONFIG"]))
        except Exception:
            pass
    for env_key, cfg_key in (
        ("TG_API_ID", "api_id"),
        ("TG_API_HASH", "api_hash"),
        ("TG_SESSION", "session"),
        ("TG_CHAT_ID", "chat_id"),
    ):
        if os.environ.get(env_key):
            cfg[cfg_key] = os.environ[env_key]
    if cfg.get("api_id"):
        cfg["api_id"] = int(cfg["api_id"])
    return cfg


def save_config(cfg: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(cfg), "utf-8")


def config_key(cfg: dict) -> str:
    raw = json.dumps({k: cfg.get(k) for k in ("api_id", "api_hash", "session", "chat_id")})
    import base64

    return base64.urlsafe_b64encode(raw.encode()).decode()


def config_from_key(key: str) -> dict:
    import base64

    raw = base64.urlsafe_b64decode(key.encode()).decode()
    return json.loads(raw)


def wants_telegram() -> bool:
    """Telegram is the default. Set STORAGE=local to keep files on disk."""
    return (os.environ.get("STORAGE") or "telegram").lower() != "local"


def build_storage():
    cfg = load_config()
    if wants_telegram():
        if not cfg.get("session"):
            return None
        try:
            return TelegramStore(
                cfg["api_id"], cfg["api_hash"], cfg["session"], cfg.get("chat_id") or "me"
            )
        except Exception:
            return None
    return LocalStorage(DATA_DIR)


STORAGE = build_storage()


def setup_needed() -> bool:
    return wants_telegram() and STORAGE is None


# --------------------------------------------------------------------------- #
# Telegram setup wizard
# --------------------------------------------------------------------------- #
class TgLogin:
    """Hosts a Telethon login client on a private event loop."""

    def __init__(self, api_id: int, api_hash: str):
        from telethon import TelegramClient
        from telethon.sessions import StringSession

        self.loop = asyncio.new_event_loop()
        self.ready = threading.Event()
        threading.Thread(target=self._run, daemon=True).start()
        self.ready.wait(10)
        self.client = TelegramClient(StringSession(), api_id, api_hash)

    def _run(self):
        asyncio.set_event_loop(self.loop)
        self.ready.set()
        self.loop.run_forever()

    def call(self, coro):
        return asyncio.run_coroutine_threadsafe(coro, self.loop).result()

    async def _start(self, phone: str):
        await self.client.connect()
        sent = await self.client.send_code_request(phone)
        return sent.phone_code_hash

    async def _sign_in_code(self, phone: str, code: str, phone_code_hash: str):
        from telethon.errors import SessionPasswordNeededError

        try:
            await self.client.sign_in(phone=phone, code=code, phone_code_hash=phone_code_hash)
            return "ok"
        except SessionPasswordNeededError:
            return "password"

    async def _sign_in_password(self, password: str):
        await self.client.sign_in(password=password)

    async def _session_string(self):
        return self.client.session.save()

    async def _verify(self, chat_id):
        await self.client.send_message(chat_id, "ApnaVault-TG connected ✅")


SETUPS: dict[str, dict] = {}


def setup_page() -> str:
    return template("setup.html")


@app.get("/setup", response_class=HTMLResponse)
def setup_get():
    if not setup_needed() and STORAGE and getattr(STORAGE, "kind", "") == "telegram":
        return RedirectResponse("/")
    return HTMLResponse(setup_page())


@app.post("/api/setup/start")
def setup_start(request: Request, api_id: str = Form(...), api_hash: str = Form(...),
                phone: str = Form(...)):
    api_id = api_id.strip()
    api_hash = api_hash.strip()
    phone = phone.strip()
    if not api_id.isdigit():
        raise HTTPException(400, "api_id sirf number hota hai (jaise 1234567).")
    if not phone.startswith("+"):
        raise HTTPException(400, "Phone number + ke saath likho, jaise +919876543210.")
    login = TgLogin(int(api_id), api_hash)
    try:
        code_hash = login.call(login._start(phone))
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, f"Code nahi bhej paye: {exc}")
    sid = secrets.token_urlsafe(16)
    SETUPS[sid] = {
        "login": login, "api_id": int(api_id), "api_hash": api_hash,
        "phone": phone, "code_hash": code_hash,
    }
    resp = JSONResponse({"step": "code"})
    resp.set_cookie("vault_setup", sid, httponly=True, samesite="lax", path="/")
    return resp


@app.post("/api/setup/code")
def setup_code(request: Request, code: str = Form(...)):
    sid = request.cookies.get("vault_setup")
    st = SETUPS.get(sid)
    if not st:
        raise HTTPException(400, "Setup session expire ho gaya — dobara shuru karo.")
    code = code.strip().replace(" ", "")
    try:
        result = st["login"].call(
            st["login"]._sign_in_code(st["phone"], code, st["code_hash"])
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, f"Code galat lag raha hai: {exc}")
    if result == "password":
        return {"step": "password"}
    return _finish_setup(sid)


@app.post("/api/setup/password")
def setup_password(request: Request, password: str = Form(...)):
    sid = request.cookies.get("vault_setup")
    st = SETUPS.get(sid)
    if not st:
        raise HTTPException(400, "Setup session expire ho gaya — dobara shuru karo.")
    try:
        st["login"].call(st["login"]._sign_in_password(password.strip()))
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, f"Password galat hai: {exc}")
    return _finish_setup(sid)


def _finish_setup(sid: str):
    global STORAGE
    st = SETUPS.get(sid)
    login = st["login"]
    session = login.call(login._session_string())
    cfg = {
        "api_id": st["api_id"],
        "api_hash": st["api_hash"],
        "session": session,
        "chat_id": "me",
    }
    try:
        login.call(login._verify("me"))
    except Exception:
        pass
    save_config(cfg)
    STORAGE = TelegramStore(cfg["api_id"], cfg["api_hash"], cfg["session"], "me")
    META.storage = STORAGE
    META.load()
    SETUPS.pop(sid, None)
    return {"step": "done", "config_key": config_key(cfg)}


# --------------------------------------------------------------------------- #
# Metadata index (JSON), persisted through storage
# --------------------------------------------------------------------------- #
class Meta:
    def __init__(self, storage):
        self.storage = storage
        self.lock = threading.Lock()
        self.data = {"users": {}, "files": [], "seq": 0}

    def load(self) -> None:
        raw = self.storage.load_index() if self.storage else None
        if raw:
            try:
                self.data = json.loads(raw.decode("utf-8"))
            except Exception:
                pass
        self.data.setdefault("users", {})
        self.data.setdefault("files", [])
        self.data.setdefault("seq", 0)

    def save(self) -> None:
        if self.storage:
            self.storage.save_index(json.dumps(self.data).encode("utf-8"))

    def next_id(self) -> int:
        self.data["seq"] = int(self.data.get("seq", 0)) + 1
        return self.data["seq"]

    def find(self, file_id: int, username: str) -> Optional[dict]:
        for f in self.data["files"]:
            if f["id"] == file_id and f["username"] == username:
                return f
        return None


META = Meta(STORAGE)


def _sessions() -> dict:
    return META.data.setdefault("sessions", {})


# --------------------------------------------------------------------------- #
# Sessions
# --------------------------------------------------------------------------- #
def set_session_cookie(resp: Response, token: str) -> None:
    resp.set_cookie(
        SESSION_COOKIE,
        token,
        max_age=SESSION_TTL,
        httponly=True,
        samesite="none" if COOKIE_SECURE else "lax",
        secure=COOKIE_SECURE,
        path="/",
    )


def make_session(username: str) -> str:
    token = secrets.token_urlsafe(32)
    with META.lock:
        sessions = _sessions()
        now = time.time()
        for k in [k for k, v in sessions.items() if v.get("expires", 0) < now]:
            sessions.pop(k, None)
        sessions[hashlib.sha256(token.encode()).hexdigest()] = {
            "username": username,
            "expires": now + SESSION_TTL,
        }
        META.save()
    return token


def current_user(request: Request) -> Optional[str]:
    token = request.cookies.get(SESSION_COOKIE)
    if not token:
        return None
    rec = _sessions().get(hashlib.sha256(token.encode()).hexdigest())
    if not rec or rec["expires"] < time.time():
        return None
    return rec["username"]


def require_user(request: Request) -> str:
    user = current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="login required")
    return user


def file_row(f: dict) -> dict:
    return {
        "id": f["id"],
        "orig_name": f["orig_name"],
        "size": f["size"],
        "size_h": human_size(f["size"]),
        "mime": f["mime"],
        "kind": f["kind"],
        "has_thumb": bool(f.get("thumb_key")),
        "starred": int(f.get("starred", 0)),
        "deleted": int(f.get("deleted", 0)),
        "uploaded_at": f["uploaded_at"],
    }


# --------------------------------------------------------------------------- #
# Assets
# --------------------------------------------------------------------------- #
def asset(name: str) -> str:
    return EMBEDDED[name]


def template(name: str) -> str:
    return EMBEDDED[name]


# --------------------------------------------------------------------------- #
# Pages
# --------------------------------------------------------------------------- #
@app.get("/static/style.css")
def _css():
    return Response(asset("style.css"), media_type="text/css")


@app.get("/static/app.js")
def _js():
    return Response(asset("app.js"), media_type="application/javascript")


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    if setup_needed():
        return RedirectResponse("/setup")
    if not current_user(request):
        return RedirectResponse("/login")
    return HTMLResponse(template("app.html"))


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    if setup_needed():
        return RedirectResponse("/setup")
    if current_user(request):
        return RedirectResponse("/")
    needs = len(META.data.get("users", {})) == 0
    html = template("login.html").replace(
        "{% if not needs_setup %}hidden{% endif %}", "" if needs else "hidden"
    )
    return HTMLResponse(html)


# --------------------------------------------------------------------------- #
# Auth API
# --------------------------------------------------------------------------- #
@app.post("/api/register")
def register(username: str = Form(...), password: str = Form(...)):
    username = username.strip()
    if len(username) < 3:
        raise HTTPException(400, "Username kam se kam 3 character ka ho.")
    if len(password) < 6:
        raise HTTPException(400, "Password kam se kam 6 character ka ho.")
    with META.lock:
        if username in META.data["users"]:
            raise HTTPException(400, "Ye username pehle se hai.")
        META.data["users"][username] = {
            "password_hash": hash_password(password),
            "created_at": now_iso(),
        }
        META.save()
    return {"ok": True}


@app.post("/api/login")
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    rec = META.data["users"].get(username.strip())
    if not rec or not verify_password(password, rec["password_hash"]):
        raise HTTPException(401, "Username ya password galat hai.")
    resp = JSONResponse({"ok": True})
    set_session_cookie(resp, make_session(username.strip()))
    return resp


@app.post("/api/logout")
def logout(request: Request):
    token = request.cookies.get(SESSION_COOKIE)
    if token:
        with META.lock:
            _sessions().pop(hashlib.sha256(token.encode()).hexdigest(), None)
            META.save()
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(SESSION_COOKIE, path="/")
    return resp


@app.get("/api/me")
def me(request: Request):
    return {"username": require_user(request)}


# --------------------------------------------------------------------------- #
# Upload
# --------------------------------------------------------------------------- #
@app.post("/api/upload")
async def upload(request: Request, files: list[UploadFile] = File(...)):
    user = require_user(request)
    saved = 0
    for up in files:
        name = safe_name(up.filename)
        data = await up.read()
        mime = up.content_type or mimetypes.guess_type(name)[0] or "application/octet-stream"
        kind = classify(name, mime)
        with META.lock:
            fid = META.next_id()
        key = f"files/{fid}_{name}"
        STORAGE.put(key, data)
        thumb_key = None
        if kind == "image":
            tb = thumb_bytes(data)
            if tb:
                thumb_key = f"thumbs/{fid}.jpg"
                STORAGE.put(thumb_key, tb)
        with META.lock:
            META.data["files"].append(
                {
                    "id": fid,
                    "username": user,
                    "orig_name": name,
                    "key": key,
                    "size": len(data),
                    "mime": mime,
                    "kind": kind,
                    "thumb_key": thumb_key,
                    "starred": 0,
                    "deleted": 0,
                    "uploaded_at": now_iso(),
                    "deleted_at": None,
                }
            )
            META.save()
        saved += 1
    return {"ok": True, "count": saved}


# --------------------------------------------------------------------------- #
# Listing
# --------------------------------------------------------------------------- #
@app.get("/api/files")
def list_files(request: Request, view: str = "all", kind: str = "all", q: str = ""):
    user = require_user(request)
    q = (q or "").lower()
    out = []
    total_size = 0
    total_count = 0
    for f in META.data["files"]:
        if f["username"] != user:
            continue
        deleted = int(f.get("deleted", 0))
        if not deleted:
            total_count += 1
            total_size += f["size"]
        if view == "trash" and not deleted:
            continue
        if view in ("all", "starred") and deleted:
            continue
        if view == "starred" and not f.get("starred"):
            continue
        if kind != "all" and f["kind"] != kind:
            continue
        if q and q not in f["orig_name"].lower():
            continue
        out.append(file_row(f))
    out.sort(key=lambda x: x["id"], reverse=True)
    return {
        "files": out,
        "stats": {"count": total_count, "size": total_size, "size_h": human_size(total_size)},
    }


# --------------------------------------------------------------------------- #
# Serving files
# --------------------------------------------------------------------------- #
def _range_headers(size: int, mime: str, request: Request, download_name: Optional[str]):
    rng = request.headers.get("range")
    disp = "attachment" if download_name else "inline"
    fname = download_name or "file"
    headers = {
        "Accept-Ranges": "bytes",
        "Content-Disposition": f'{disp}; filename="{fname}"',
    }
    start, end = 0, size - 1
    status = 200
    if rng:
        m = re.match(r"bytes=(\d*)-(\d*)", rng)
        if m:
            start = int(m.group(1)) if m.group(1) else 0
            end = int(m.group(2)) if m.group(2) else size - 1
            end = min(end, size - 1)
            if start > end:
                raise HTTPException(416, "bad range")
            status = 206
            headers["Content-Range"] = f"bytes {start}-{end}/{size}"
    length = end - start + 1
    headers["Content-Length"] = str(length)
    return start, length, status, headers


def stream_file(f: dict, request: Request, download_name: Optional[str] = None):
    size = f["size"]
    mime = f["mime"] or "application/octet-stream"
    start, length, status, headers = _range_headers(size, mime, request, download_name)
    return StreamingResponse(
        STORAGE.stream(f["key"], start, length),
        status_code=status,
        headers=headers,
        media_type=mime,
    )


@app.get("/api/file/{file_id}/view")
def view_file(request: Request, file_id: int):
    user = require_user(request)
    f = META.find(file_id, user)
    if not f:
        raise HTTPException(404, "not found")
    return stream_file(f, request)


@app.get("/api/file/{file_id}/download")
def download_file(request: Request, file_id: int):
    user = require_user(request)
    f = META.find(file_id, user)
    if not f:
        raise HTTPException(404, "not found")
    return stream_file(f, request, download_name=f["orig_name"])


@app.get("/api/thumb/{file_id}")
def thumb(request: Request, file_id: int):
    user = require_user(request)
    f = META.find(file_id, user)
    if not f or not f.get("thumb_key"):
        raise HTTPException(404, "no thumb")
    data = STORAGE.get(f["thumb_key"])
    if not data:
        raise HTTPException(404, "no thumb")
    return Response(data, media_type="image/jpeg")


# --------------------------------------------------------------------------- #
# Mutations
# --------------------------------------------------------------------------- #
def _set_flag(file_id: int, user: str, **changes):
    with META.lock:
        f = META.find(file_id, user)
        if not f:
            raise HTTPException(404, "not found")
        f.update(changes)
        META.save()
    return f


@app.post("/api/file/{file_id}/star")
def star(request: Request, file_id: int):
    user = require_user(request)
    with META.lock:
        f = META.find(file_id, user)
        if not f:
            raise HTTPException(404, "not found")
        f["starred"] = 0 if f.get("starred") else 1
        META.save()
        return {"starred": f["starred"]}


@app.post("/api/file/{file_id}/trash")
def trash_one(request: Request, file_id: int):
    user = require_user(request)
    _set_flag(file_id, user, deleted=1, deleted_at=now_iso())
    return {"ok": True}


@app.post("/api/file/{file_id}/restore")
def restore_one(request: Request, file_id: int):
    user = require_user(request)
    _set_flag(file_id, user, deleted=0, deleted_at=None)
    return {"ok": True}


@app.post("/api/trash")
def trash_many(request: Request, payload: dict):
    user = require_user(request)
    ids = set(payload.get("ids", []))
    with META.lock:
        for f in META.data["files"]:
            if f["username"] == user and f["id"] in ids:
                f["deleted"] = 1
                f["deleted_at"] = now_iso()
        META.save()
    return {"ok": True, "count": len(ids)}


@app.post("/api/restore")
def restore_many(request: Request, payload: dict):
    user = require_user(request)
    ids = set(payload.get("ids", []))
    with META.lock:
        for f in META.data["files"]:
            if f["username"] == user and f["id"] in ids:
                f["deleted"] = 0
                f["deleted_at"] = None
        META.save()
    return {"ok": True, "count": len(ids)}


@app.delete("/api/file/{file_id}")
def delete_forever(request: Request, file_id: int):
    user = require_user(request)
    with META.lock:
        f = META.find(file_id, user)
        if not f:
            raise HTTPException(404, "not found")
        META.data["files"].remove(f)
        META.save()
    STORAGE.delete(f["key"])
    if f.get("thumb_key"):
        STORAGE.delete(f["thumb_key"])
    return {"ok": True}


@app.post("/api/empty-trash")
def empty_trash(request: Request):
    user = require_user(request)
    with META.lock:
        doomed = [f for f in META.data["files"] if f["username"] == user and f.get("deleted")]
        for f in doomed:
            META.data["files"].remove(f)
        META.save()
    for f in doomed:
        STORAGE.delete(f["key"])
        if f.get("thumb_key"):
            STORAGE.delete(f["thumb_key"])
    return {"ok": True, "count": len(doomed)}


# --------------------------------------------------------------------------- #
# Recovery (whole vault as a ZIP)
# --------------------------------------------------------------------------- #
@app.get("/api/recover")
def recover(request: Request):
    user = require_user(request)
    files = [f for f in META.data["files"] if f["username"] == user and not f.get("deleted")]
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".zip")
    tmp.close()
    with zipfile.ZipFile(tmp.name, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
        for f in files:
            data = STORAGE.get(f["key"])
            if data is None:
                continue
            z.writestr(f["orig_name"], data)
    return FileResponse(
        tmp.name,
        media_type="application/zip",
        filename=f"apnavault-recovery-{now_iso()[:10]}.zip",
    )


# --------------------------------------------------------------------------- #
# Startup
# --------------------------------------------------------------------------- #
@app.on_event("startup")
def _startup() -> None:
    META.load()
